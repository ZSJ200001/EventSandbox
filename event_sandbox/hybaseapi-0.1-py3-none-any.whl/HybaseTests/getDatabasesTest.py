# coding:utf-8
import time
import sys
import os

rootPath = os.path.dirname(os.getcwd())
sys.path.append(rootPath)

from hybaseapi.TRSConnection import TRSConnection
from hybaseapi.ConnectParams import ConnectParams

conn = TRSConnection("http://192.168.190.161:5555", "admin", "hybase@trs300229.", ConnectParams())
# getDatabases( DBNames="*", options={})
# DBNames 数据库名列表，多个数据库名间以半角分号、逗号分隔，可使用通配符
# options 可选参数，默认为空。 目前提供以下可选参数
#         list.db.splitted用于设定是否包含分裂子库，取值范围[true|false]，默认值false，即不包含分裂子库。
#         alias.orig.db用于设定是否获取虚拟数据库的目标数据库的所有对象，取值范围[true/false]，默认值false，不获取。
dbArray = conn.getDatabases(DBNames="demo")
if len(dbArray) == 0:
    print("数据库demo不存在！")
else:
    print(" name:  " + str(dbArray[0].getName()))
    print(" getType:  " + str(dbArray[0].getType()))
    print(" 创建日期:  " + str(dbArray[0].getCreateDate()))
    print(" 更新日期:  " + str(dbArray[0].getUpdateDate()))
    print(" 记录总数:  " + str(dbArray[0].getRecordNum64()))
    print(" 默认检索字段:  " + str(dbArray[0].getDefSearchColumn()))
    print(" 副本数:  " + str(dbArray[0].getReplications()))
    print(" 分词器:  " + str(dbArray[0].getParser()))
    cols = dbArray[0].getAllColumns()
    for col in cols:
        print("列名:" + col.name)
