# coding:utf-8
import time
import sys
import os

rootPath = os.path.dirname(os.getcwd())
sys.path.append(rootPath)

from hybaseapi.TRSConnection import TRSConnection
from hybaseapi.ConnectParams import ConnectParams
from hybaseapi.SearchParams import SearchParams
from hybaseapi.TRSExport import TRSExport
from HybaseTests.PrintRecordListener import PrintRecordListener


#TRSExport(conn: TRSConnection = None, filePath=None, append=True, recordListener=None)
#filePath=None 以调用传入的recordListener。此处recordListener可自定义，参考PrintRecordListener实现所有方法即可


params = ConnectParams()
params.setTimeout(6000000)
conn = TRSConnection("http://192.168.190.161:5555", "admin", "hybase@trs300229.", ConnectParams())
filePath = None
listener = PrintRecordListener()
export = TRSExport(conn, filePath, True, listener)
searchparams = SearchParams()
searchparams.setReadColumns('rowid;标题;正文')
export.export('demo', "*:*", 0, 1000, searchparams)
