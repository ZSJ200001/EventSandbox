# coding:utf-8
from hybaseapi.TRSRecord import TRSRecord


class PrintRecordListener:
    resultNoSortSet = None

    def __init__(self, resultNoSortSet=None):
        self.resultNoSortSet = resultNoSortSet

    @staticmethod
    def getDataDir():
        return None

    @staticmethod
    def onBegin():
        return None

    def onRecord(self, record: TRSRecord):
        print(repr(record.recColumnsData))

    def onEnd(self):
        return None

