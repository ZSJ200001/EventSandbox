# coding:utf-8
import time
import sys
import os

from hybaseapi.OperationParams import OperationParams
from hybaseapi.TRSDatabase import TRSDatabase
from hybaseapi.TRSDatabaseColumn import TRSDatabaseColumn
from hybaseapi.TRSInputRecord import TRSInputRecord

rootPath = os.path.dirname(os.getcwd())
sys.path.append(rootPath)

from hybaseapi.TRSConnection import TRSConnection
from hybaseapi.ConnectParams import ConnectParams

# conn = TRSConnection("http://192.168.105.219:5555", "admin", "trsadmin", ConnectParams())
# conn = TRSConnection("http://119.254.15.202:8285", "admin", "trsadmin123.", ConnectParams())
conn = TRSConnection("http://119.254.15.204:9555", "admin", "trsadmin", ConnectParams())
ret = conn.deleteDatabase("test_vector_1024")
print(ret)
