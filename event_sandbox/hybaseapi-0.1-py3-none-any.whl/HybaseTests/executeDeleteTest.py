# coding:utf-8
import time
import sys
import os

from hybaseapi.OperationParams import OperationParams
from hybaseapi.TRSInputRecord import TRSInputRecord

rootPath = os.path.dirname(os.getcwd())
sys.path.append(rootPath)

from hybaseapi.TRSConnection import TRSConnection
from hybaseapi.ConnectParams import ConnectParams
conn = TRSConnection("http://192.168.190.161:5555", "admin", "hybase@trs300229.", ConnectParams())
# conn = TRSConnection("http://192.168.105.219:5555", "admin", "trsadmin", ConnectParams())

toDelUid = "CNcnENgnGgMwMDAiC3N5c3RlbS5kZW1v"
delNum = conn.executeDelete("demo", [toDelUid])
print("删除了"+str(delNum)+"条数据")
