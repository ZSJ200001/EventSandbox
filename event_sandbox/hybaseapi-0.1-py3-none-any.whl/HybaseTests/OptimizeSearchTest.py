# coding:utf-8
import time
import sys
import os

rootPath = os.path.dirname(os.getcwd())
sys.path.append(rootPath)

from hybaseapi.TRSConnection import TRSConnection
from hybaseapi.ConnectParams import ConnectParams
from hybaseapi.OptimizeSearchSample import OptimizeSearchSample
from hybaseapi.SearchParams import SearchParams

conn = TRSConnection("http://192.168.190.161:5555", "admin", "hybase@trs300229.", ConnectParams())
dbname = "system.weibo"
rs = conn.executeSelect(dbname, "((版名:要闻 AND 版次:1))", 0, 10, SearchParams())
print(rs.getNumFound())

where = OptimizeSearchSample()
where.addORWhere("版名:要闻")
# executeOptimizeSelect(strSources, where: OptimizeSearchSample, start, recordNum, params: SearchParams)
# strWhere   检索表达式，如果要在表达式中 指定检索字段 ，格式为“字段名:检索条件 ”，为空表示无条件检
# where      {@link IOptimizeSearchWhere}使用特殊检索表达式，实现快捷检索，目前仅支持使用
#            {@linkHybase.hybaseapi.OptimizeSearch1}方式优化，使用方法参考示例
# start        结果记录返回的起始位置，起始位置超过记录总数时返回空集
# recordNum  结果记录返回个数，实际返回的个数有可能小于recordNum
# params     检索参数类对象，检索其它可选参数通过此类设置
# 返回 TRSResultSet 结果
rs1 = conn.executeOptimizeSelect(dbname, where, 0, 10, SearchParams())
print(rs1.getNumFound())
