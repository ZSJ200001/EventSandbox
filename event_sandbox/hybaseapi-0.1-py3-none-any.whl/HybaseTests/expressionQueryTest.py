# coding:utf-8
import time
import sys
import os

rootPath = os.path.dirname(os.getcwd())
sys.path.append(rootPath)

from hybaseapi.TRSConnection import TRSConnection
from hybaseapi.ConnectParams import ConnectParams
from hybaseapi.SearchParams import SearchParams

# conn = TRSConnection("http://192.168.105.219:5555", "admin", "trsadmin", ConnectParams())
conn = TRSConnection("http://192.168.190.161:5555", "admin", "hybase@trs300229.", ConnectParams())

sParams = SearchParams()
# expressionQuery(strSources, query, expression, params)
# strWhere   检索表达式，如果要在表达式中 指定检索字段 ，格式为“字段名:检索条件 ”，为空表示无条件检
# query      检索表达式，如果要在表达式中指定检索字段 ，格式为“字段名:检索条件 ”，为空表示无条件检索
# expression 统计表达式
# params     检索参数类对象，检索其它可选参数通过此类设置
# 返回 TRSResultSet 结果
result1 = conn.expressionQuery("demo", None, "SUM(intId)", sParams)
print(result1.getExpressionResult("SUM(intId)"))
