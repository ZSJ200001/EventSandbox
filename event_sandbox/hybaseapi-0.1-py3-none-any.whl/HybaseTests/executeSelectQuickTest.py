# coding:utf-8
import time
import sys
import os

rootPath = os.path.dirname(os.getcwd())
sys.path.append(rootPath)

from hybaseapi.TRSConnection import TRSConnection
from hybaseapi.ConnectParams import ConnectParams
from hybaseapi.SearchParams import SearchParams

# conn = TRSConnection("http://192.168.50.231:5555", "admin", "trsadmin", ConnectParams())
conn = TRSConnection("http://192.168.190.161:5555", "admin", "hybase@trs300229.", ConnectParams())

param = SearchParams()
param.setSortMethod("RELEVANCE")
param.setReadColumns("标题;作者;正文")
param.setDefaultColumn("正文")
t1 = time.time()
# executeSelectQuick(strSources, strWhere, estimateUnit, start, recordNum, params: SearchParams)
# strSources 检索目标数据库名称列表。多个对象名间以半角分号、逗号分隔，不能为空
# strWhere   检索表达式，如果要在表达式中 指定检索字段 ，格式为“字段名:检索条件 ”，为空表示无条件检
# estimateUnit 检索范围，在记录总数已达到estimateUnit的部分字库中检索。例如，一个数据库有5个子库，每个子库1万条，共5万条记录，
#              如果该参数设置为18000，那么，只需检索2个子库。
# start        结果记录返回的起始位置，起始位置超过记录总数时返回空集
# recordNum  结果记录返回个数，实际返回的个数有可能小于recordNum
# params     检索参数类对象，检索其它可选参数通过此类设置
# 返回 TRSResultSet 结果
resultSet = conn.executeSelectQuick("demo", "中国", 1000, 0, 100, param)
if resultSet is not None:
    print("命中记录数：" + str(resultSet.numFound))
    i = 0
    while i < resultSet.size():
        resultSet.moveNext()
        re = resultSet.get()
        print("正文"+re.getString("正文"))
        print("作者"+re.getString("作者"))
        print("标题" + re.getString("标题"))
        i += 1
