# coding:utf-8
import time
import sys
import os

from hybaseapi import SearchParams
from hybaseapi.OperationParams import OperationParams
from hybaseapi.TRSInputRecord import TRSInputRecord

rootPath = os.path.dirname(os.getcwd())
sys.path.append(rootPath)

from hybaseapi.TRSConnection import TRSConnection
from hybaseapi.ConnectParams import ConnectParams

conn = TRSConnection("http://192.168.190.161:5555", "admin", "hybase@trs300229.", ConnectParams())

delNum = conn.executeDeleteQuery("demo", "作者:h", SearchParams())
print("删除了"+str(delNum)+"条数据")
