# coding:utf-8
import time
import sys
import os

rootPath = os.path.dirname(os.getcwd())
sys.path.append(rootPath)

from hybaseapi.TRSConnection import TRSConnection
from hybaseapi.TRSResultSet import TRSResultSet
from hybaseapi.ConnectParams import ConnectParams
from hybaseapi.OptimizeSearchSample import OptimizeSearchSample
from hybaseapi.SearchParams import SearchParams

# conn = TRSConnection("http://192.168.105.219:5555", "admin", "trsadmin", ConnectParams())
conn = TRSConnection("http://192.168.190.161:5555", "admin", "hybase@trs300229.", ConnectParams())

# 普通检索

param = SearchParams()
param.setReadColumns("IR_RETWEETED_SCREEN_NAME")
# executeSelect(strSources, strWhere, start, recordNum, params: SearchParams)
# strSources 检索目标数据库名称列表。多个对象名间以半角分号、逗号分隔，不能为空
# strWhere   检索表达式，如果要在表达式中 指定检索字段 ，格式为“字段名:检索条件 ”，为空表示无条件检
# start        结果记录返回的起始位置，起始位置超过记录总数时返回空集
# recordNum  结果记录返回个数，实际返回的个数有可能小于recordNum
# params     检索参数类对象，检索其它可选参数通过此类设置
# 返回 TRSResultSet 结果
resultSet = conn.executeSelect("system.weibo", None, 0, 2, param)
i = 0
while i < resultSet.size():
    resultSet.moveNext()
    re = resultSet.get()
    if re.getString("IR_RETWEETED_SCREEN_NAME") is not None:
        print("rowid:" + re.getString("IR_RETWEETED_SCREEN_NAME"))
    i += 1

resultSet = conn.executeSelect("system.weibo", None, 0, 2, param)
i = 0
while i < resultSet.size():
    resultSet.moveNext()
    re = resultSet.get()
    if re.getString("IR_RETWEETED_SCREEN_NAME") is not None:
        print("rowid:" + re.getString("IR_RETWEETED_SCREEN_NAME"))
    i += 1
