# coding:utf-8
import time
import sys
import os

rootPath = os.path.dirname(os.getcwd())
sys.path.append(rootPath)

from hybaseapi.TRSConnection import TRSConnection
from hybaseapi.ConnectParams import ConnectParams
from hybaseapi.SearchParams import SearchParams

conn = TRSConnection("http://192.168.190.161:5555", "admin", "hybase@trs300229.", ConnectParams())
param = SearchParams()
param.setReadColumns("标题;正文")
# executeAsynSelect(strSources, strWhere, start, recordNum, params: SearchParams)
# strSources 检索目标数据库名称列表。多个对象名间以半角分号、逗号分隔，不能为空
# strWhere   检索表达式，如果要在表达式中 指定检索字段 ，格式为“字段名:检索条件 ”，为空表示无条件检索
# start      结果记录返回的起始位置，起始位置超过记录总数时返回空集
# recordNum  结果记录返回个数，实际返回的个数有可能小于recordNum
# params     检索参数类对象，检索其它可选参数通过此类设置
# 返回 TRSResultSet 统计结果
ret_ctn = 0
rs = conn.executeAsynSelect("demo", "", 0, 5000, param)
while rs.getProgress() != "100%":
    time.sleep(1000)
    rs = conn.getAsynSelectResult(rs.getSearchid())
    print(str(rs.getProgress()) + ":" + str(rs.getNumFound()))
i = 0
while i < rs.size():
    rs.moveNext()
    re = rs.get()
    # print(re.getString("正文"))
    # print(re.getString("标题"))
    i += 1
    ret_ctn += 1
    print(str(ret_ctn))
