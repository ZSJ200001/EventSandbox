# coding:utf-8
import time
import sys
import os

from hybaseapi.OperationParams import OperationParams
from hybaseapi.TRSInputRecord import TRSInputRecord

rootPath = os.path.dirname(os.getcwd())
sys.path.append(rootPath)

from hybaseapi.TRSConnection import TRSConnection
from hybaseapi.ConnectParams import ConnectParams

# conn = TRSConnection("http://192.168.105.219:5555", "admin", "trsadmin", ConnectParams())
conn = TRSConnection("http://119.254.15.202:8285", "admin", "trsadmin123.", ConnectParams())

key = ["ID", "TIMESTAMP", "name"]
content = ["a", "b", "c"]
must = ["m", "m", "m"]

records = []

for idx in range(30):
    r = TRSInputRecord()
    i = 0
    while i < len(key):
        val = content[i]+str(idx)
        r.addColumn(key[i], val)
        i = i + 1
    records.append(r)

insertNum = conn.executeInsert("name", records, OperationParams())
print("插入了"+str(insertNum)+"条数据")
