# coding:utf-8
import time
import sys
import os

rootPath = os.path.dirname(os.getcwd())
sys.path.append(rootPath)

from hybaseapi.TRSConnection import TRSConnection
from hybaseapi.ConnectParams import ConnectParams
from hybaseapi.SearchParams import SearchParams

conn = TRSConnection("http://192.168.190.161:5555", "admin", "hybase@trs300229.", ConnectParams())
params = SearchParams()
# categoryQuery(strSources, query, defaultColumn, categoryColumn, topNum, params: SearchParams = SearchParams())
# strSources     检索目标数据库名称列表。多个对象名间以半角分号、逗号分隔，不能为空。
# query          检索表达式，如果要在表达式中指定检索字段 ，格式为“字段名:检索条件 ”，为空表示无条件检索
# defaultColumn  默认检索字段
# categoryColumn 分类字段，多个字段之间以半角分号、逗号分隔，不能为空
# topNum         返回类别统计数最多的前多少个类别统计
# params         搜索参数
# 返回 TRSResultSet 统计结果
result = conn.categoryQuery("demo", "*:*", "正文", "作者", 5000, params)
print("result numFound:" + str(result.getNumFound()))
category = result.getCategoryMap()
for k, v in category.items():
    print(str(k) + ":" + str(v))
