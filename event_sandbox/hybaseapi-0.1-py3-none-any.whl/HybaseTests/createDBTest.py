# coding:utf-8
import time
import sys
import os

from hybaseapi.OperationParams import OperationParams
from hybaseapi.TRSDatabase import TRSDatabase
from hybaseapi.TRSDatabaseColumn import TRSDatabaseColumn
from hybaseapi.TRSInputRecord import TRSInputRecord

rootPath = os.path.dirname(os.getcwd())
sys.path.append(rootPath)

from hybaseapi.TRSConnection import TRSConnection
from hybaseapi.ConnectParams import ConnectParams

# conn = TRSConnection("http://192.168.105.219:5555", "admin", "trsadmin", ConnectParams())
# conn = TRSConnection("http://119.254.15.202:8285", "admin", "trsadmin123.", ConnectParams())
conn = TRSConnection("http://119.254.15.204:9555", "admin", "trsadmin", ConnectParams())
database = TRSDatabase(name="test_vector_1024")
database.addColumn(TRSDatabaseColumn("image_id", TRSDatabaseColumn.TYPE_NUMBER))
image_vector_column = TRSDatabaseColumn("image_vector", TRSDatabaseColumn.TYPE_VECTOR)
image_vector_column.setProperty("index.vector.dims", '1024')
image_vector_column.setProperty("index.vector.arithmetic", "hnsw")
image_vector_column.setProperty("index.vector.similarity", "EUCLIDEAN")
image_vector_column.setProperty("index.hnsw.m", '16')
image_vector_column.setProperty("index.hnsw.ef", '100')
image_vector_column.setProperty("index.vector.encoding.type", "FLOAT")
database.addColumn(image_vector_column)
database.addColumn(TRSDatabaseColumn("image_base64",TRSDatabaseColumn.TYPE_DOCUMENT))

ret = conn.createDatabase(database)
print(ret)
