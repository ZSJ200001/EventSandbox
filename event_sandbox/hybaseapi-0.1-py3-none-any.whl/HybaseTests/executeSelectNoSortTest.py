# coding:utf-8
import time
import sys
import os

rootPath = os.path.dirname(os.getcwd())
sys.path.append(rootPath)

from hybaseapi.TRSConnection import TRSConnection
from hybaseapi.ConnectParams import ConnectParams
from hybaseapi.SearchParams import SearchParams

# conn = TRSConnection("http://192.168.50.94:8888", "admin", "trsadmin", ConnectParams())
# conn = TRSConnection("http://192.168.190.161:5555", "admin", "hybase@trs300229.", ConnectParams())
conn = TRSConnection("http://119.254.15.204:9555", "admin", "trsadmin", ConnectParams())

param = SearchParams()
# 设置读取的Col以及启用无序检索
# param.setReadColumns("rowid;日期;标题;作者;附件")
# param.setProperty("hybase.search.nosort", "true")

# executeSelectNoSort(strSources, strWhere, start, recordNum, params: SearchParams)
# strSources 检索目标数据库名称列表。多个对象名间以半角分号、逗号分隔，不能为空
# strWhere   检索表达式，如果要在表达式中 指定检索字段 ，格式为“字段名:检索条件 ”，为空表示无条件检
# recordNum  结果记录返回个数，实际返回的个数有可能小于recordNum
# params     检索参数类对象，检索其它可选参数通过此类设置
# 返回 TRSResultSet 结果

resultSet = conn.executeSelectNoSort("test_vector_1024", "", 0, 7000, param)
i = 0
print("命中记录数：" + str(resultSet.numFound))
while resultSet.moveNext():
    re = resultSet.get()
    image_vector = re.getString("image_vector")
    if len(image_vector) > 0:
        print(len(image_vector.split(",")))
        print("image_vector" + image_vector)
    else:
        print('rowid null')

