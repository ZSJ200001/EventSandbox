from hybaseapi import TRSConnection, TRSRPC_pb2
from .SearchParams import SearchParams
from .TRSRPC_pb2 import SearchRPC
from .TRSRecord import TRSRecord


class TRSResultSet:
    closed = False
    numFound = 0
    start = 0
    curRecordID = -1
    records = None
    categoryMap = None
    facetMap = None
    expressionMap = None
    searchid = ""
    progress = "100%"
    dbHitsNum = None
    conn: TRSConnection = None
    searchParmas: SearchParams = None
    searchRequest: SearchRPC.SearchRecordRequest = None

    def __init__(self, conn=None, categoryMap=None, expressionMap=None, facetMap=None, foundNum=None):
        self.conn = conn
        self.categoryMap = categoryMap
        self.facetMap = facetMap
        self.expressionMap = expressionMap
        self.numFound = foundNum
        self.records = []
        self.categoryMap = {}
        self.facetMap = {}
        self.expressionMap = {}
        self.dbHitsNum = {}

    def getSearchRequest(self):
        return self.searchRequest

    def setSearchRequest(self, sr: SearchRPC.SearchRecordRequest):
        self.searchRequest = sr

    def setSearchParams(self, sp: SearchParams):
        self.searchParmas = sp

    def reset(self):
        self.conn = None
        self.searchRequest = None
        self.categoryMap = None
        self.expressionMap = None
        self.dbHitsNum = None
        for rec in self.records:
            rec.close()
        self.records.clear()
        self.curRecordID = -1

    def close(self):
        if self.closed:
            return
        self.reset()

    def size(self):
        return len(self.records)

    def getNumFound(self):
        return self.numFound

    def getStart(self):
        return self.start

    def add(self, e: TRSRecord):
        self.records.append(e)

    def getCurrentRecordID(self):
        return self.curRecordID

    def setNumFound(self, numFound):
        self.numFound = numFound

    def setStart(self, start):
        self.start = start

    def get(self):
        if self.curRecordID == -1:
            return None

        rec = self.records[self.curRecordID]
        rec.setSearchParams(self.searchParmas)
        if self.searchRequest is not None and not TRSRecord.UUID == self.searchRequest.readColumns and len(
                rec.getColumnMap()) == 0:
            builder = SearchRPC.getRecordsRequest()
            builder.readColumns = self.searchRequest.readColumns
            builder.colorColumns = self.searchRequest.colorColumns
            builder.colorWords = self.searchRequest.query
            builder.cutSize = self.searchRequest.cutSize
            builder.searchOpts.extend(self.searchRequest.opts)
            idsBuilder = TRSRPC_pb2.StringList()
            i = self.curRecordID
            while i < min(self.curRecordID + 100, self.size()):
                r = self.records[i]
                if len(r.getColumnMap()) > 0:
                    break
                idsBuilder.str.append(r.recUUID)
                i += 1

            builder.uuidList.CopyFrom(idsBuilder)
            response = self.conn.getRecords(builder)
            toGet = len(idsBuilder.str)
            self.clearRecords(0, self.curRecordID)
            self.clearRecords(self.curRecordID + toGet, self.size())
            resultList = response.record
            fillStart = self.curRecordID
            if resultList is not None:
                for re in resultList:
                    record = self.records[fillStart]
                    record.reset()
                    record.setDbName(re.dbName)
                    for col in re.columns:
                        record.addValue(col.name, col)
                    fillStart += 1
        return rec

    def getRecord(self, recordID):
        if not self.moveTo(recordID):
            return None
        return self.get()

    def moveFirst(self):
        if len(self.records) == 0:
            self.curRecordID = -1
            return False
        self.curRecordID = 0
        return True

    def moveLast(self):
        if len(self.records) == 0:
            self.curRecordID = -1
            return False
        self.curRecordID = len(self.records) - 1
        return True

    def moveNext(self):
        if self.curRecordID >= len(self.records) - 1:
            return False
        self.curRecordID += 1
        return True

    def movePrevious(self):
        if self.curRecordID <= 0:
            return False
        self.curRecordID -= 1
        return True

    def moveTo(self, recordID):
        if recordID < 0 or recordID > len(self.records) - 1:
            return False
        self.curRecordID = recordID
        return True

    def getCategoryCount(self, categoryColumn):
        if self.categoryMap is None:
            return 0
        categoryInfo = self.categoryMap.get(categoryColumn)
        if categoryInfo is None:
            return 0
        return len(categoryInfo)

    def getCategory(self, categoryName, categoryColumn=None):
        if self.categoryMap is None or len(self.categoryMap) == 0:
            return 0
        if categoryColumn is not None:
            categoryInfo = self.categoryMap.get(categoryColumn)
        else:
            categoryInfo = self.categoryMap.values()[0]
        if categoryInfo is None:
            return 0
        value = categoryInfo.get(categoryName)
        if value is None:
            return 0
        return value

    def getCategoryName(self, index: int, categoryColumn: str = None):
        if self.categoryMap is None:
            raise Exception("category map is null")
        if categoryColumn is not None:
            categoryInfo = self.categoryMap.get(categoryColumn)
        else:
            key = self.categoryMap.keys()[0]
            categoryInfo = self.categoryMap.get(key)
        if categoryInfo is None:
            raise Exception("cannot fine category info for column: " + categoryColumn)
        if index < 0 or index > (len(self.categoryMap) - 1):
            raise Exception("index is out of bounds!")
        return categoryInfo.keys()[index]

    def clearRecords(self, fromIndex, toIndex):
        i = fromIndex
        while i < toIndex:
            rec = self.records[i]
            rec.reset()
            i += 1

    def getCategoryNum(self, index: int, categoryColumn: str = None):
        if self.categoryMap is None or len(self.categoryMap) == 0:
            raise Exception("category map is null")
        if categoryColumn is not None:
            categoryInfo = self.categoryMap.get(categoryColumn)
        else:
            key = self.categoryMap.keys()[0]
            categoryInfo = self.categoryMap.get(key)
        if categoryInfo is None or len(categoryInfo) == 0:
            raise Exception("cannot find category info")
        if index < 0 or index > (len(self.categoryMap) - 1):
            raise Exception("index is out of bounds!")
        return categoryInfo.values()[index]

    def getCategoryMap(self, categoryColumn=None):
        if self.categoryMap is not None and len(self.categoryMap) > 0:
            if categoryColumn is not None:
                return self.categoryMap.get(categoryColumn)
            else:
                return self.categoryMap['0']
        return None

    def getProgress(self):
        return self.progress

    def getDBHitsNum(self, includeSplitDB=None):
        if includeSplitDB is None:
            includeSplitDB = False
        if includeSplitDB:
            return self.dbHitsNum
        ret = {}
        for k, v in self.dbHitsNum.items():
            if "#" in k:
                continue
            ret.update({k: v})
        return ret

    def getSearchid(self):
        return self.searchid

    def getExpressionResult(self, fieldName=None):
        if fieldName is None:
            return self.expressionMap
        resultField: TRSRPC_pb2.ResultField = self.expressionMap.get(fieldName)
        if resultField is None:
            return 0
        else:
            return resultField.doubleValue

    def getFacetInfo(self, prevFacetValue, currFacet):
        res = {}
        if prevFacetValue is None or currFacet is None or len(currFacet)==0:
            return res
        inputKey = currFacet
        i = 0
        while i < len(prevFacetValue):
            inputKey += ";" + prevFacetValue.get(i)
            i += 1
        if self.facetMap.get(inputKey) is None:
            res = self.facetMap.get(inputKey)
        return res























