from hybaseapi import TRSRPC_pb2
from .TRSObject import TRSObject
from .TRSRPC_pb2 import SearchRPC, SchemaRPC


class TRSDatabaseColumn(TRSObject):
    TYPE_DATE = 0
    TYPE_NUMBER = 1
    TYPE_CHAR = 2
    TYPE_PHRASE = 3
    TYPE_DOCUMENT = 4
    TYPE_BIT = 5
    TYPE_OBJECT = 6
    TYPE_VECTOR = 7
    DEFAULTVALUE = "defaultvalue"
    VALUESOURCE = "valuesource"
    MULTIVALUE = "multivalue"
    VALUEMUST = "valuemust"
    NOTINDEX = "notindex"
    NOTSTORE = "notstore"
    STOREFILE = "storefile"
    CENTSTORE = "centstore"
    ISCATEGORY = "iscategory"
    ISFLOAT = "isfloat"
    ALIAS = "alias"
    COMMENT = "comment"
    name = ""
    sname = None
    colType = 0

    def __init__(self, name='', _type=None):
        super().__init__()
        self.name = name
        self.colType = _type

    def getName(self):
        return self.name

    def getColType(self):
        return self.colType

    def getSName(self):
        return self.sname

    def setMultivalue(self, multiValue):
        self.setProperty(self.MULTIVALUE, multiValue)
        return self

    def isMultivalue(self):
        value = self.getProperty(MULTIVALUE)
        return value

    def setValueMust(self, valueMust):
        self.setProperty(self.VALUEMUST, valueMust)
        return self

    def isValueMust(self):
        value = self.getProperty(self.VALUEMUST)
        return value

    def setNotIndex(self, isNotIndex):
        self.setProperty(self.NOTINDEX, self.isNotIndex)
        return self

    def isNotIndex(self):
        return self.getProperty(self.NOTINDEX)

    def setNotStore(self, isNotStore):
        self.setProperty(self.NOTSTORE, isNotStore)
        return self

    def isNotStore(self):
        return self.getProperty(self.NOTSTORE)

    def setStoreFile(self, isStoreFile):
        self.setBoolProperty(self.STOREFILE, isStoreFile);
        return self

    def isStoreFile(self):
        return self.getProperty(self.STOREFILE)

    def setCentStore(self, isCentStore):
        self.setProperty(self.CENTSTORE, isCentStore)
        return self

    def isCentStore(self):
        return self.getProperty(self.CENTSTORE)

    def read(self, inputData: SchemaRPC.ColumnInfo):
        self.name = inputData.name
        self.sname = inputData.sname
        self.colType = inputData.type

        if len(inputData.property) > 0 :
            colPropertyList = inputData.property
            for p in colPropertyList:
                self.setProperty(p.key, p.value)

    def getAlias(self):
        return self.getProperty(self.ALIAS)

    def setAlias(self, alias):
        self.setProperty(self.ALIAS, alias)
        return self

    def getComment(self):
        return self.getProperty(self.COMMENT)

    def setComment(self, comment):
        return self.setProperty(self.COMMENT, comment);

    def getDefaultValue(self):
        return self.getProperty(self.DEFAULTVALUE)

    def setDefaultValue(self, defaultValue):
        return self.setProperty(self.DEFAULTVALUE, defaultValue)

    def setValueSource(self, valueSource):
        return self.setProperty(self.VALUESOURCE, valueSource)

    def setIsFloat(self, isFloat):
        self.setProperty(self.ISFLOAT, isFloat)
        return self

    def isFloat(self):
        return self.getProperty(self.ISFLOAT)

    def setCategoryColumn(self, isCategory):
        self.setProperty(self.ISCATEGORY, isCategory)
        return self

    def isCategoryColumn(self):
        return self.getProperty(self.ISCATEGORY)

