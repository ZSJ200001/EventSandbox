class TRSConstants:
    STRING_TYPE = 0
    INT_TYPE = 1
    LONG_TYPE = 2
    FLOAT_TYPE = 3
    DOUBLE_TYPE = 4
    DATE_TYPE = 5
    FILE_TYPE = 6
    DOCUMENT_TYPE = 7
    API_URL_SCHEMA = "/api/schema.do"
    DEFALT_COLUMN_SEPCHAR = ";"
    DEFAULT_TIMEOUT = 60000
    MERGENUM = "$mergeNum$"
    TOTALNUM = "$totalNum$"
    OptimizeSearch1 = 0
