class TRSFileBuilder:
    prefix = None
    charset = "GB18030"
    append = False
    KEY_MAX_FILE_SIZE = "export.file.maxsize"
    maxFileSize = KEY_MAX_FILE_SIZE
    basePath = ""
    baseFile = None
    fileOrd = 0
    curFile = None
    curWriter = None
    curRenew = False
    totalRecordCount = 0

    def __init__(self, filePath, append, options=None):
        self.totalFileList = []
        if filePath is None:
            raise Exception("filePath is None")
        self.basePath = filePath
        self.baseFile = open(self.basePath, 'r')
        self.curFile = open(filePath, 'r')
        self.append = append

        if options is not None:
            if options.__contains__(self.KEY_MAX_FILE_SIZE):
                val = options.get(self.KEY_MAX_FILE_SIZE)
                if val >= 1 * 1024 * 1024:
                    self.maxFileSize = val
            self.prefix = options.get("parser.trs.prefix")
