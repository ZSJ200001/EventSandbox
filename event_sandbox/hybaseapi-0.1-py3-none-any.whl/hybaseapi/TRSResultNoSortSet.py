from .RecordListener import RecordListener
from .TRSExport import TRSExport
from .TRSRecord import TRSRecord
from .TRSResultSet import TRSResultSet
import queue


class TRSResultNoSortSet(TRSResultSet):
    export = None
    closed = False
    failure = None
    value: TRSRecord = None
    resultSize = 0
    MaxRecordsSize = 128 * 1024 * 1024
    exportVersion = 7

    def __init__(self, conn=None, categoryMap=None, expressionMap=None, facetMap=None, foundNum=None):
        super().__init__()
        self.records = queue.Queue()
        self.conn = conn
        self.categoryMap = categoryMap
        self.facetMap = facetMap
        self.expressionMap = expressionMap
        self.numFound = foundNum

    def moveNext(self):
        if self.searchRequest.start >= self.numFound:
            return False
        if self.export is None:
            self.initExport()
        while True:
            if self.failure is not None:
                return False
            # noinspection PyBroadException
            try:
                self.value = self.records.get(timeout=5)
            except Exception:
                failure = Exception
                return False

            if self.value is not None:
                self.resultSize += (-1 * self.value.computeSize(False))
                return True
            if self.closed and self.records.empty() == 0:
                return False

    def get(self):
        if self.failure is not None:
            raise self.failure
        return self.value

    def setExportVersion(self, exportVersion):
        self.exportVersion = exportVersion

    def close(self):
        if not self.closed:
            self.closed = True

    def initExport(self):
        self.export = TRSExport(self.conn, recordListener=RecordListener(self))
        self.export.setExportVersion(self.exportVersion)
        self.export.resume(self.searchid, self.searchRequest.source, self.searchRequest.start, self.searchRequest.num)





