from . import TRSRPC_pb2
from .TRSRPC_pb2 import OptimizeQuery1


class Builder:
    orQueryList = []
    mustQuery = None

    def build(self):
        return OptimizeSearch1(self)

    def addORWhere(self, where):
        self.orQueryList.append(where)

    def setMustWhere(self, where):
        self.mustQuery = where

    def clear(self):
        self.orQueryList = []
        self.mustQuery = None


class OptimizeSearchSample:
    orQueryList = []
    mustQuery = ""

    def __init__(self, orQueryList=[], mustQuery=""):
        self.orQueryList = orQueryList
        self.mustQuery = mustQuery

    def addORWhere(self, where):
        self.orQueryList.append(where)

    def setMustWhere(self, where):
        self.mustQuery = where

    def clear(self):
        self.orQueryList = []
        self.mustQuery = None

    @staticmethod
    def newBuilder():
        return Builder()

    def OptimizeSearchSample(self, o: Builder):
        self.orQueryList = o.orQueryList
        self.mustQuery = o.mustQuery

    def genWhereString(self):
        if len(self.orQueryList) == 0:
            return self.mustQuery
        sb = ""
        sb += "(" + self.orQueryList[0] + ")"
        i = 1
        while i < len(self.orQueryList):
            sb += " OR (" + self.orQueryList[i] + ")"
            i += 1
        sb += ")"

        if self.mustQuery is not None and len(self.mustQuery) > 0:
            if self.mustQuery.strip().startswith("NOT "):
                sb += self.mustQuery
            else:
                sb += " AND (" + self.mustQuery + ")"
        return sb

    def genParamsMap(self):
        if len(self.orQueryList) == 0:
            return None
        ret = {}
        query = OptimizeQuery1()
        for q in self.orQueryList:
            filterQuery = TRSRPC_pb2.FilterQuery()
            filterQuery.query = q
            query.filterQuery.append(filterQuery)
        if self.mustQuery is not None and len(self.mustQuery) > 0:
            query.mustQuery = self.mustQuery
        try:
            ret.update({"search.filter.query": query.SerializeToString()})
        except Exception:
            raise Exception
        return ret
