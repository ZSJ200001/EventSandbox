from datetime import time
import time
import random
import re
import requests
import urllib

from hybaseapi import OperationParams

from .RequestBuilder import RequestBuilder
from .ResultSetParser import ResultSetParser
from .TRSConstants import TRSConstants
from .TRSDatabase import TRSDatabase, DBRequestBuilder
from .TRSRPC_pb2 import SearchRPC, MaintRPC, SchemaRPC, Report
from .TRSResultSet import TRSResultSet
from .ConnectParams import ConnectParams
from .OptimizeSearchSample import OptimizeSearchSample
from .SearchParams import SearchParams


class TRSConnection:
    closed = False
    loadingExtractorFailed = False
    loadingThreads = 0
    INSERT_SKIP_ERROR = "insert.skip.error"
    SKIP_FILE_ERROR = "skip.file.error"
    HYBASE_HEADER_LENGTH = "X-Hybase-HeaderLength"
    SIZE_1M = 1024 * 1024
    SIZE_1G = 1024 * SIZE_1M
    MAX_RESPONSE_SIZE = 64 * SIZE_1M
    DefaultSoTimeOut = 5 * 60 * 1000
    API_URL_SCHEMA = "/api/schema.do"

    def __init__(self, serverList, userID, password, params: ConnectParams):
        self.failedHosts = {}
        self.serverURL = serverList
        self.randomServerList = []
        self.randomServerList.extend(re.split('[,;]', serverList))
        self.randomServerLast = None
        self.userID = userID
        self.password = password
        self.params = params
        self.http4ShortClient = None
        self.http4LongClient = None

    def getHttp4ShortClient(self):
        return self.http4ShortClient

    def getHttp4LongClient(self):
        return self.http4LongClient

    def String(self):
        return self.serverURL

    def getUserID(self):
        return self.userID

    def getPassword(self):
        return self.password

    def getConnectParams(self):
        return self.connectParams

    def getLastConnectURL(self):
        return self.randomServerList

    def sendHttpRequest(self, urlPath, isLongRequest, isRandom, priorIndex,
                        soTimeOut=TRSConstants.DEFAULT_TIMEOUT, data=None, newHeader={}):
        response = None
        retryCount = 0
        headers = {**{"X-Hybase-UserID": self.userID, "X-Hybase-Password": self.password}, **newHeader}
        curServer = self.selectServer(isRandom, priorIndex)
        while retryCount < len(self.randomServerList) and curServer is not None:
            curServer = self.selectServer(isRandom, priorIndex)
            retryCount += 1
            # 根据文档例子，HTTPSConnection()参数是host，request里设置post/get和path
            if isLongRequest:
                # 长连接不设置超时
                res = requests.post(url=curServer + urlPath, data=data, headers=headers)
            else:
                if soTimeOut < self.DefaultSoTimeOut:
                    soTimeOut = self.DefaultSoTimeOut
                    res = requests.post(url=curServer + urlPath, data=data, headers=headers, timeout=soTimeOut)
            break
        if res is None:
            raise Exception("no server is available!")
        return res

    def executeCommand(self, cmd, params):
        ret = ""
        path = "/api/cmd.do?cmd=" + cmd + ""
        sb = ""
        for k, v in params:
            if len(sb) > 0:
                sb = sb + "\u0001"
            sb = sb + k + "=" + v
        # java源码 req.get().setEntity(new ByteArrayEntity(sb.toString().getBytes("UTF-8")));
        # 未对sb做处理，环境搭建好后通过fiddle检查传递的数据
        response = requests.post(url=self.serverURL + path, data=sb)
        return response.text

    def checkFailedHosts(self):
        if len(self.failedHosts) == 0:
            return
        recycledHosts = []
        for host in self.failedHosts.keys():
            if time.time() > (self.failedHosts.get(host) + 30 * 1000):
                recycledHosts.append(host)
        for s in recycledHosts:
            self.failedHosts.pop(s)

    def selectServer(self, isRandom, priorIndex):
        self.checkFailedHosts()

        if priorIndex != -1:
            idx = priorIndex
        else:
            try:
                idx = self.randomServerList.index(self.randomServerLast)
            except ValueError:
                idx = -1
            if idx < 0 or idx >= len(self.randomServerList) or isRandom:
                idx = random.randint(0, len(self.randomServerList))
        selectedAddr = None
        i = 0
        while i < len(self.randomServerList):
            selectedAddr = self.randomServerList[(i + idx) % len(self.randomServerList)]
            if not self.failedHosts.__contains__(selectedAddr):
                self.randomServerLast = selectedAddr
                return selectedAddr
            i += 1
        return selectedAddr

    def getPriorIP(self, strWhere):
        if len(self.randomServerList) > 1 and strWhere is not None:
            return random.randint(0, len(self.randomServerList))
        else:
            return -1

    def executeSelect(self, strSources, strWhere, start, recordNum, params: SearchParams):
        if params is None:
            raise Exception("params can't be null!")
        if strSources is None:
            raise Exception("strSources can't be null!")
        if start < 0 or recordNum < 0:
            raise Exception("start or recordNum paramter can't be negative!")
        if strWhere is None:
            strWhere = "*:*"

        resultSet: TRSResultSet
        searchReponse: SearchRPC.SearchRecordResponse
        path = "/api/search.do"
        params.setProperty("read.batch.partial", True)
        request = RequestBuilder.buildSearchReq(strSources, strWhere, start, recordNum, params)

        priorIP = self.getPriorIP(strWhere)
        response = self.sendHttpRequest(path, False, False, priorIP, params.getTimeOut() * 1000,
                                        request.SerializeToString())
        searchReponse = SearchRPC.SearchRecordResponse()
        try:
            searchReponse.ParseFromString(response.content)
        except Exception as e:
            raise Exception(response.content)
        resultSet = ResultSetParser.processSearchResponse(searchReponse, self)
        resultSet.setStart(start)
        resultSet.setSearchRequest(request)
        resultSet.setSearchParams(params)
        return resultSet

    def executeSelectNoSort(self, strSources, strWhere, start, recordNum, params: SearchParams):
        if strSources is None:
            raise Exception("strSources can't be null!")
        if params is None:
            raise Exception("params can't be null!")
        if start < 0 or recordNum < 0:
            raise Exception("start or recordNum paramter can't be negative!")
        if strWhere is None:
            strWhere = "*:*"

        sr = RequestBuilder.buildSearchReq(strSources, strWhere, start, recordNum,
                                           params)
        reqBuilder = MaintRPC.ExportRecordRequest()
        reqBuilder.source = strSources
        reqBuilder.searchRequest.CopyFrom(sr)
        request = reqBuilder

        path = "/api/exportrecords.do?action=getExportID"
        response = self.sendHttpRequest(path, True, False, -1, data=request.SerializeToString())
        exportVersion = 7
        versionHeader = response.headers["Export-Version"]
        if versionHeader is not None:
            exportVersion = int(versionHeader)
        exportRecordResponse = MaintRPC.ExportRecordResponse()
        exportRecordResponse.ParseFromString(response.content)
        return ResultSetParser.parserExportRecordResponse(exportRecordResponse, self, exportVersion)

    def executeOptimizeSelect(self, strSources, where: OptimizeSearchSample, start, recordNum, params: SearchParams):
        if where is None:
            return self.executeSelect(strSources, "*:*", start, recordNum, params)
        strWhere = where.genWhereString()
        whereParams = where.genParamsMap()
        if whereParams is None or len(whereParams) == 0:
            return self.executeSelect(strSources, strWhere, start, recordNum, params)

        if params is None:
            raise Exception("params can't be null!")

        params.setProperty("search.optimize.type", "OptimizeSearch1")

        for k, v in whereParams.items():
            str = v.decode();
            params.setProperty(k, v)
        return self.executeSelect(strSources, strWhere, start, recordNum, params)

    def executeSelectQuick(self, strSources, strWhere, estimateUnit, start, recordNum, params: SearchParams):
        if params is None:
            raise Exception("params can't be null!")
        params.setEstimateUnit(estimateUnit)
        params.setQuickSearch(True)
        return self.executeSelect(strSources, strWhere, start, recordNum, params)

    def executeAsynSelect(self, strSources, strWhere, start, recordNum, params: SearchParams):
        if params is None:
            raise Exception("params can't be null!")
        params.setProperty("asynsearch.mask", "1")
        return self.executeSelect(strSources, strWhere, start, recordNum, params)

    def getAsynSelectResult(self, searchID):
        if searchID is None or len(searchID) == 0:
            raise Exception("searchID can't be null!")
        path = "/api/getasynresult.do?searchid=" + searchID
        response = self.sendHttpRequest(path, False, False, -1)
        searchReponse = SearchRPC.SearchRecordResponse.ParseFromString(response.read())
        resultSet = ResultSetParser.processSearchResponse(searchReponse, self)
        return resultSet

    def getRecords(self, request: SearchRPC.getRecordsRequest):
        path = "/api/getrecords.do"
        response = self.sendHttpRequest(path, True, False, -1, data=request.SerializeToString())
        searchReponse = SearchRPC.SearchRecordResponse()
        searchReponse.ParseFromString(response.content)
        return searchReponse

    def categoryQuery(self, strSources, query, defaultColumn, categoryColumn, topNum,
                      params: SearchParams = SearchParams()):
        if strSources is None:
            raise Exception("strSources can't be null!")
        if categoryColumn is None:
            raise Exception("categoryColumn can't be null!")
        if not topNum > 0:
            raise Exception("topNum paramter must be positive!")
        if query is None:
            query = "*:*"

        path = "/api/category.do"
        request = RequestBuilder.buildCategoryQueryReq(strSources, query, defaultColumn, categoryColumn, topNum, params)
        response = self.sendHttpRequest(path, False, False, self.getPriorIP(query), params.getTimeOut() * 1000,
                                        data=request.SerializeToString())
        categoryReponse = SearchRPC.CategoryQueryResponse()
        categoryReponse.ParseFromString(response.content)
        resultList = ResultSetParser.processCategoryResponse(categoryReponse)
        return resultList

    def categoryOptimizeQuery(self, strSources, query, defaultColumn, categoryColumn, topNum,
                              params):
        if query is None:
            return self.categoryQuery(strSources, "*:*", defaultColumn, categoryColumn, topNum, params)
        strWhere = query.genWhereString()
        whereParams = query.genParamsMap()
        if whereParams is None or len(whereParams) == 0:
            return self.categoryQuery(strSources, strWhere, defaultColumn, categoryColumn, topNum, params)
        if params is None:
            raise Exception("params can't be null!")
        params.setProperty("search.optimize.type", query.getOptimizeType())
        for k, v in whereParams.items():
            params.setProperty(k, v)
        return self.categoryQuery(strSources, strWhere, defaultColumn, categoryColumn, topNum, params)

    def facetQuery(self, strSources, query, defaultColumn, categoryColumns, topNum, params: SearchParams):
        if strSources is None:
            raise Exception("strSources can't be null!")
        if categoryColumn is None:
            raise Exception("categoryColumn can't be null!")
        if not topNum > 0:
            raise Exception("topNum paramter must be positive!")
        if query is None:
            query = "*:*"

        path = "/api/facet.do"
        request = RequestBuilder.buildFacetQueryReq(strSources, query, defaultColumn,
                                                    categoryColumns, topNum, params)

    def getDatabases(self, DBNames="*", options={}):
        databaseList = None
        path = TRSConstants.API_URL_SCHEMA + "?action=GET_DB" + "&dbname=" + urllib.parse.quote(DBNames)
        request = TRSDatabase.buildListDBRequest(DBNames, options)
        response = self.sendHttpRequest(path, False, False, -1, data=request.SerializeToString())
        result = SchemaRPC.ListDBResponse()
        result.ParseFromString(response.content)
        if len(result.db) == 0:
            return []
        databaseList = []
        dbList = result.db
        for db in dbList:
            database = TRSDatabase()
            database.readFromRPC(protoDB=db)
            databaseList.append(database)
        return databaseList

    def expressionQuery(self, strSources, query, expression, params):
        if strSources is None:
            raise Exception("strSources can't be null!")
        if expression is None:
            raise Exception("expression can't be null!")

        if query is None:
            query = "*:*"
        path = "/api/expression.do"
        request = RequestBuilder.buildExpressionQueryReq(strSources, query, expression, params)
        response = self.sendHttpRequest(path, False, False, self.getPriorIP(query),
                                        data=request.SerializeToString(), soTimeOut=params.getTimeOut() * 1000)
        expressionReponse = SearchRPC.ExpressionQueryResponse()
        try:
            expressionReponse.ParseFromString(response.content)
        except Exception as e:
            raise Exception(response.content)
        result = ResultSetParser.processExpressionResponse(expressionReponse)
        return result

    def close(self):
        if self.closed:
            return

    #         clear Conn Here

    def executeInsert(self, DBName, records, params: OperationParams):
        if DBName is None:
            raise Exception("DBName can not be null!")
        if records is None or len(records) <= 0:
            return

        maxBufferSize = 16 * self.SIZE_1M
        addReq = MaintRPC.InsertRecordRequest()
        addReq.source = DBName

        totalReadSize = 0
        batchStart = 0
        batchEnd = 0
        insertedNum = 0

        i = 0
        while i < len(records):
            totalReadSize = 0
            batchStart = i
            while totalReadSize < maxBufferSize and i < len(records):
                recordBuilder = None
                try:
                    buildRet = RequestBuilder.buildInputRecord(records[i], True, totalReadSize, params)
                    recordBuilder = buildRet[0]
                    newBufferSize = totalReadSize + buildRet[1]
                    totalReadSize = newBufferSize
                except BaseException:
                    i = i + 1
                    print("Error while buildRecord")
                if recordBuilder is not None:
                    recordBuilder.tag = i
                    addReq.record.append(recordBuilder)
                i = i + 1
                batchEnd = i
            if len(addReq.record) > 0:
                skipError = False
                if params.getProperty(self.SKIP_FILE_ERROR) is not None:
                    skipError = params.getProperty(self.SKIP_FILE_ERROR)
                insertedNum = insertedNum + self.flushLoadRequest(addReq, skipError)
        return insertedNum

    def flushLoadRequest(self, request: MaintRPC.InsertRecordRequest, skipFileError):
        if len(request.record) == 0:
            return 0
        path = "/api/insertrecords.do"
        response = self.sendHttpRequest(path, True, True, -1,
                                        data=request.SerializeToString(),
                                        newHeader={self.HYBASE_HEADER_LENGTH: str(request.ByteSize())})
        ret = Report()
        ret.ParseFromString(response.content)
        while len(request.record) > 0:
            request.record.pop()
        return ret.insertedNum

    def executeDelete(self, DBName: str, uids: []):
        path = "/api/deleterecords.do"
        option = {}
        request = RequestBuilder.buildDeleteReqByID(DBName, uids, option)
        response = self.sendHttpRequest(path, False, False, -1,
                                        data=request.SerializeToString(),
                                        newHeader={self.HYBASE_HEADER_LENGTH: str(request.ByteSize())})
        ret = Report()
        try:
            ret.ParseFromString(response.content)
        except Exception as e:
            raise Exception(response.content)
        return ret.deletedNum

    def executeDeleteQuery(self, DBName: str, query: str, params: SearchParams, ):
        if query is None or len(query) == 0:
            raise Exception("Query can't be null!")
        qList = [query]
        request = RequestBuilder.buildDeleteReqByQuery(DBName, qList, params);
        path = "/api/deletequery.do"
        response = self.sendHttpRequest(path, False, False, -1,
                                        data=request.SerializeToString(),
                                        newHeader={self.HYBASE_HEADER_LENGTH: str(request.ByteSize())})
        ret = Report()
        ret.ParseFromString(response.content)
        return ret.deletedNum

    def executeUpdate(self, DBName: str, records: [], params: OperationParams):
        if DBName is None:
            raise Exception("DBName can not be null!")
        if records is None or len(records) == 0:
            return

        builder = MaintRPC.UpdateRecordRequest()
        builder.source = DBName
        skipError = False
        if params.getProperty(self.SKIP_FILE_ERROR) is not None:
            skipError = params.getProperty(self.SKIP_FILE_ERROR)
        builder.skipFileError = skipError
        if params is not None:
            for item in list(params.properties.items()):
                builder.options.append(item)
        MAX_INSERT_SIZE = 16 * self.SIZE_1M
        totalReadSize = 0
        i = 0
        while i < len(records):
            while totalReadSize < MAX_INSERT_SIZE and i < len(records):
                record = None
                try:
                    buildRet = RequestBuilder.buildInputRecord(records[i], False, totalReadSize, params)
                    record = buildRet[0]
                    totalReadSize = totalReadSize + buildRet[1]
                except BaseException:
                    i = i + 1
                    print("Error while buildRecord")
                if record is not None:
                    record.tag = i
                    builder.record.append(record)
                i = i + 1
                batchEnd = i
            if len(builder.record) > 0:
                self.executeUpdateRequest(DBName, builder, params)

    def executeUpdateRequest(self, DBName: str, updateReq: MaintRPC.UpdateRecordRequest, params: OperationParams):
        if updateReq is None:
            return 0
        path = "/api/updaterecords.do"
        response = self.sendHttpRequest(path, True, False, -1,
                                        data=updateReq.SerializeToString(),
                                        newHeader={self.HYBASE_HEADER_LENGTH: str(updateReq.ByteSize())})
        ret = Report()
        ret.ParseFromString(response.content)
        return ret.updatedNum + ret.insertedNum

    def createDatabase(self, db: TRSDatabase):
        if db.getType() != TRSDatabase.TYPE_ALIAS and db.getType() != TRSDatabase.TYPE_MIRROR and db.getType() != TRSDatabase.TYPE_BALANCE:
            if len(db.addcolumns) == 0 and db.columns is not None:
                for key in db.columns.keys():
                    db.addcolumns.update(key,db.columns.get(key))
            if len(db.addcolumns) == 0:
                raise Exception("no field definition found in database！")

        path = self.API_URL_SCHEMA + "?action=create"
        request = DBRequestBuilder.buildCreateDbReq(db)
        response = self.sendHttpRequest(path, True, False, -1,
                                        data=request.SerializeToString(),
                                        newHeader={self.HYBASE_HEADER_LENGTH: str(request.ByteSize())})
        ret = Report()
        ret.ParseFromString(response.content)
        return True

    def deleteDatabase(self, dbName:str, recordOnly=True):
        if dbName is None:
            raise Exception("database name can't be null")
        path = TRSConstants.API_URL_SCHEMA + "?action=delete_db" + "&dbname=" + urllib.parse.quote(
            dbName) + "&hybase.drop.records=" + str(recordOnly)
        response = self.sendHttpRequest(path, True, False, -1,)
        ret = Report()
        ret.ParseFromString(response.content)
        return True

