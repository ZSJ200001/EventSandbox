from .TRSConstants import TRSConstants
from dateutil.parser import parse


class TRSInputColumn:
    name = ""
    value = None
    boost = 1.0
    type = 0

    def __init__(self, name=None, value=None):
        self.name = name
        self.value = value

    def getName(self):
        return self.name

    def setName(self, name):
        self.name = name

    def getValue(self):
        return self.value

    def setValue(self, value):
        self.value = value

    def getBoost(self):
        return self.boost

    def setBoost(self, boost):
        self.boost = boost

    def getColumnType(self):
        return self.type

    def setType(self, columnType):
        self.type = columnType

    def setIntValue(self, value):
        self.setType(TRSConstants.INT_TYPE)
        self.setValue(value)

    def setLongValue(self, value):
        self.setType(TRSConstants.LONG_TYPE)
        self.setValue(value)

    def setFloatValue(self, value):
        self.setType(TRSConstants.FLOAT_TYPE)
        self.setValue(value)

    def setDoubleValue(self, value):
        self.setType(TRSConstants.DOUBLE_TYPE)
        self.setValue(value)

    def setDateValue(self, value):
        self.setType(TRSConstants.DATE_TYPE)
        self.setValue(parse(value))

    def setFileValue(self, fPath: str = None, fvalue=None, fvalues=None):
        if fPath is not None:
            self.setType(TRSConstants.FILE_TYPE)
            self.setValue(fPath)
        if fvalue is not None:
            self.setType(TRSConstants.FILE_TYPE)
            self.setValue(os.path.realpath(fvalue))
        if fvalues is not None:
            self.value = None
            for f in fvalues:
                self.addValue(f.getAbsolutePath())
            self.setFileValue(fPath=self.value)

    def setDocumentValue(self, fPath: str = None, fvalue=None, fvalues=None):
        if fPath is not None:
            self.setType(TRSConstants.DOCUMENT_TYPE)
            self.setValue(fPath)
        if fvalue is not None:
            self.setType(TRSConstants.DOCUMENT_TYPE)
            self.setValue(os.path.realpath(fvalue))
        if fvalues is not None:
            self.value = None
            for f in fvalues:
                self.addValue(f.getAbsolutePath())
            self.setDocumentValue(fPath=self.value)

    def addValue(self, value):
        if value is None:
            self.setValue(value)
        else:
            self.value = value + TRSConstants.DEFALT_COLUMN_SEPCHAR + value
