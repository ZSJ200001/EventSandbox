from enum import Enum

from hybaseapi import TRSRPC_pb2
from .TRSDatabaseColumn import TRSDatabaseColumn
from .TRSObject import TRSObject
from .TRSRPC_pb2 import SchemaRPC


class TRSDatabase(TRSObject):
    # 数据库模式， 表示数据库为单节点模式
    MODE_SINGLE = 0
    # 数据库模式， 表示数据库为分布式模式
    MODE_DISTRIBUTED = 1
    # 数据库模式， 表示数据库为内存模式
    MODE_MEMORY = 2
    # 数据库类型， 表示数据库为单节点数据库类型
    TYPE_DATABASE = 0
    # 数据库类型，表示数据库为自动分裂视图
    TYPE_VIEW = 1
    # 数据库类型，表示数据库为虚拟数据库
    TYPE_ALIAS = 2
    # 数据库类型，表示分时归档视图
    TYPE_FIFO = 3
    # 数据库类型，表示镜像数据库
    TYPE_MIRROR = 4
    # 数据库类型，表示负载均衡视图
    TYPE_BALANCE = 5
    # 分词器名称，表示“按词” 分词
    ANALYZER_TRSSTD = "analyzer001"
    # 分词器名称，表示“按字” 分词
    ANALYZER_TRSCJK = "analyzer002"

    SEG_PINYIN_ALL = "pinyin_all"
    SEG_PINYIN_FIRST = "pinyin_first"

    # 数据库创建日期属性
    CREATEDATE = "createdate"
    # 数据库更新日期属性
    UPDATEDATE = "updatedate"
    # 数据库字段个数属性
    COLUMNNUM = "columnnum"
    # 数据库包含记录总数属性
    RECORDNUM = "recordnum"
    # 镜面数据库
    MIRRORDB = "mirrordb"
    # 镜面数据库副本 严格按照映射表映射
    MIRRORCOPY_EXACT = "exact"
    # 镜面数据库副本 同一个分区子库在一个节点
    MIRRORCOPY_PART = "part"
    # 镜面数据库副本  随机分布
    MIRRORCOPY_RANDOM = "random"

    DBPOLICY = Enum("DBPOLICY", ["NORMAL", "FASTEST", "SAFEST"])
    name: str = None
    mode: int = None
    type: int = None
    engineType: str = None
    policy: DBPOLICY = None
    defSearchColumn: str = None
    uniqueColumn: str = None
    parser: str = None
    replications: int = 0
    splitColumn: str = None
    splitter: str = None
    splitParams: map = None
    columns: map = None

    def __init__(self, name=None, mode=None, _type=None, policy=None):
        super().__init__()
        self.addcolumns = {}
        self.altcolumns = {}
        self.delcolumns = []
        if mode is None:
            mode = self.MODE_DISTRIBUTED
        if _type is None:
            _type = self.TYPE_VIEW

        self.name = name
        self.mode = mode
        self.type = _type
        self.policy = policy

    def getName(self):
        return self.name

    def setName(self, name):
        self.name = name

    def getEngineType(self):
        return self.engineType

    def setEngineType(self, engineType):
        self.engineType = engineType

    def addColumn(self, column: TRSDatabaseColumn):
        if self.addcolumns.__contains__(column.getName()):
            return "exists"
        self.addcolumns.update({column.getName(): column})

    def freeze(self):
        if self.columns is None and len(self.addcolumns) > 0:
            set.columns = {}
            set.columns.update(self.addcolumns)
            self.addcolumns.clear()

    def deleteColumn(self, colName):
        self.delcolumns.append(colName)

    def alterColumn(self, alterColumn: TRSDatabaseColumn):
        self.altcolumns.update({alterColumn.getName(): alterColumn})

    def clear(self):
        self.addcolumns.clear()
        self.delcolumns.clear()
        self.altcolumns.clear()

    def getColumn(self, name):
        self.freeze()
        if self.columns is None:
            return "请先调用TRSConnection.getDatabases方法获取数据库对象，再用此方法"
        return self.columns.get(name);

    def getAllColumns(self):
        self.freeze()
        if self.columns is None:
            return "请先调用TRSConnection.getDatabases方法获取数据库对象，再用此方法"
        return self.columns.values()

    def listColumns(self):
        if self.columns is None:
            return "请先调用TRSConnection.getDatabases方法获取数据库对象，再用此方法"
        return self.columns.keys()

    def getColumnCount(self):
        if self.columns is None:
            return "请先调用TRSConnection.getDatabases方法获取数据库对象，再用此方法"
        return len(self.columns)

    def getRecordNum(self):
        return self.getRecordNum64()

    def getRecordNum64(self):
        value = self.getProperty(self.RECORDNUM)
        if value is None:
            raise Exception("请先调用TRSConnection.getDatabases方法获取数据库对象，再用此方法")
        return value

    def getCreateDate(self):
        value = self.getProperty(self.CREATEDATE)
        if value is None:
            raise Exception("请先调用TRSConnection.getDatabases方法获取数据库对象，再用此方法")
        return value

    def getUpdateDate(self):
        value = self.getProperty(self.UPDATEDATE)
        if value is None:
            raise Exception("请先调用TRSConnection.getDatabases方法获取数据库对象，再用此方法")
        return value

    def getMode(self):
        return self.mode

    def getType(self):
        return self.type

    def getPolicy(self):
        return self.policy

    def setMirrorDB(self, mirrorDBName, mirrorCopy):
        self.setProperty(self.MIRRORDB, mirrorDBName)
        self.setProperty("mirror.copy", mirrorCopy)
        return self

    def getMirrorDB(self):
        return super.getProperty(self.MIRRORDB)

    def readFromRPC(self, protoDB: SchemaRPC.DatabaseInfo):
        self.name = protoDB.name
        self.mode = protoDB.mode
        self.type = protoDB.type
        self.policy = self.codeToDbpolicy(protoDB.policy)
        self.replications = protoDB.repSubNum
        if protoDB.defSearchColumn is not None:
            self.defSearchColumn = protoDB.defSearchColumn
        if protoDB.uniqueColumn is not None:
            self.uniqueColumn = protoDB.uniqueColumn
        if protoDB.parserName is not None:
            self.parser = protoDB.parserName
        if protoDB.splitter is not None:
            self.splitter = protoDB.splitter
        if protoDB.splitColumn is not None:
            self.splitColumn = protoDB.splitColumn
        if len(protoDB.splitParams) > 0:
            self.splitParams = {}
            for p in protoDB.splitParams:
                self.splitParams.update({p.key: p.value})
        self.columns = {}
        if len(protoDB.columns) > 0:
            cols = protoDB.columns
            for c in cols:
                column = TRSDatabaseColumn()
                column.read(c)
                self.columns.update({column.getName(): column})
            self.setProperty(self.COLUMNNUM, len(protoDB.columns))

        if len(protoDB.property) > 0:
            dbPropertyList = protoDB.property
            for p in dbPropertyList:
                self.setProperty(p.key, p.value)
        return self

    def codeToDbpolicy(self, _type):
        if _type == 0:
            return self.DBPOLICY.NORMAL
        elif _type == 1:
            return self.DBPOLICY.FASTEST
        elif _type == 2:
            return self.DBPOLICY.SAFEST
        else:
            raise Exception("Invalid policy")

    def getDefSearchColumn(self):
        return self.defSearchColumn

    def getReplications(self):
        return self.replications

    def getParser(self):
        return self.parser

    @staticmethod
    def buildListDBRequest(dbName, options={}):
        builder = SchemaRPC.ListDBRequest()
        builder.dbName = dbName
        if len(options.items()) > 0:
            for k, v in options.items():
                pro = TRSRPC_pb2.Property()
                pro.key = k.lower()
                pro.value = v
                builder.property.append(pro)
        return builder


class DBRequestBuilder:

    @staticmethod
    def buildColumn(col: TRSDatabaseColumn, detail):
        builder = SchemaRPC.ColumnInfo()
        properties = col.properties
        if col.getName() is None:
            raise Exception("Column name can not be null!")
        builder.name = col.getName()
        builder.type = col.getColType()
        if detail:
            for name, val in properties.items():
                pro = TRSRPC_pb2.Property()
                pro.key = name.lower()
                pro.value = val
                builder.property.append(pro)
        else:
            defaultProperty = TRSRPC_pb2.Property()
            defaultProperty.key = TRSDatabaseColumn.ISFLOAT
            defaultProperty.value = str(col.isFloat())
            builder.property.append(defaultProperty)
        return builder

    @staticmethod
    def buildCopyDBRequest(DBName: str, strSourceCols: str):
        builder = SchemaRPC.CopyDBRequest()
        builder.name = DBName
        builder.sourceColumns = strSourceCols
        return builder

    @staticmethod
    def buildCreateDbReq(db: TRSDatabase):
        builder = DBRequestBuilder.buildDatabase(db)
        return builder


    @staticmethod
    def buildDatabase(db: TRSDatabase):
        builder = SchemaRPC.CreateDBRequest()
        dbBuilder = builder.db
        if db.name is None:
            raise Exception("DBName can not be null!")
        dbBuilder.name = db.getName()
        dbBuilder.mode = db.getMode()
        dbBuilder.type = db.getType()
        if db.engineType is not None:
            dbBuilder.engineType = db.engineType
        if db.policy is not None:
            dbBuilder.policy = db.policy
        for name, column in db.addcolumns.items():
            c = DBRequestBuilder.buildColumn(column, True)
            dbBuilder.columns.append(c)
        if db.getDefSearchColumn() is not None:
            dbBuilder.defSearchColumn = db.getDefSearchColumn()
        if db.uniqueColumn is not None:
            dbBuilder.uniqueColumn = db.uniqueColumn
        if db.getParser() is not None:
            dbBuilder.parserName = db.getParser()
        if db.getReplications() != 0:
            dbBuilder.repSubNum = db.getReplications()
        if db.splitter is not None:
            dbBuilder.splitter = db.splitter
        if db.splitColumn is not None:
            dbBuilder.splitColumn = db.splitColumn
        if db.splitParams is not None:
            for key,val in db.splitParams.items():
                pro = TRSRPC_pb2.Property()
                pro.key = key.lower()
                pro.value = val
                dbBuilder.splitParams.append(pro)

        for key,val in db.properties.items():
            pro = TRSRPC_pb2.Property()
            pro.key = key.lower()
            pro.value = val
            dbBuilder.splitParams.property(pro)
        return builder