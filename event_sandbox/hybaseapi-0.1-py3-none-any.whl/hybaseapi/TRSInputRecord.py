from .TRSInputColumn import TRSInputColumn
from .TRSRecord import TRSRecord


class TRSInputRecord:
    uid = None
    boost = 1.0

    def __init__(self, rec: TRSRecord = None):
        self.columns = {}
        if rec is not None:
            for name in rec.getColumnNames():
                value = rec.getString(name)
                if value is not None and len(value) > 0:
                    self.addColumn(name, value)

    def addColumn(self, name=None, value=None, boost=1.0, col: TRSInputColumn = None):
        if col is not None:
            self.columns.update({col.getName(): col})
        elif name is not None and value is not None:
            column = TRSInputColumn(name)
            column.setValue(str(value))
            column.setBoost(boost)
            self.addColumn(col=column)

    def setUid(self, uid):
        self.uid = uid

    def getUid(self):
        return self.uid

    def getBoost(self):
        return self.boost

    def setBoost(self, boost):
        self.boost = boost

    def getColumn(self, name):
        return self.columns.get(name)

    def getColumnValue(self, name):
        col = self.getColumn(name)
        if col is None:
            return None
        return col.getValue()

    def getColumns(self):
        return self.columns.values()

    def getColumnCount(self):
        return len(self.columns)

    def getAllColumnsName(self):
        return self.columns.keys()

    def removeColumn(self, name):
        return self.columns.pop(name)

    def clear(self):
        if len(self.columns) > 0:
            self.columns = {}
