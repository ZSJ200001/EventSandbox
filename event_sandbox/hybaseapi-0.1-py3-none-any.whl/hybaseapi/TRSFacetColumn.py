class TRSFacetColumn:
    name = ""
    statColumn = ""
    statFunction = ""
    facetLabels = ""
    maxSize = 0


    def __init__(self, name, statColumn, function, facetLabels, maxSize, opts):
        self.options = {}
        self.name = name
        self.statColumn = statColumn
        self.statFunction = function
        self.facetLabels = facetLabels
        self.maxSize = maxSize
        if opts is not None and len(opts) > 0:
            self.options = opts
