class TRSObject:
    def __init__(self):
        self.properties = {}

    def setProperty(self, key, value):
        if value is None:
            print("property " + key + ":null")
        self.properties[key] = str(value)
        return self

    def getProperty(self, key):
        rev = self.properties.get(key)
        if rev is None:
            rev = self.properties.get(key.lower())
        return rev

    def keys(self):
        return self.properties.keys()

    def listProperties(self):
        if len(self.properties) == 0:
            return None
        pro = []
        for k, v in self.properties:
            pro.append(k + "=" + v)
        return pro

    def toString(self):
        if len(self.properties) == 0:
            return ""
        pro = ""
        for k, v in self.properties:
            pro = pro + k + "=" + v + ";"
        return pro
