from .TRSConstants import TRSConstants
from .TRSObject import TRSObject


class ConnectParams(TRSObject):
    # 如果在timeout时间内未连接成功，则放弃此次连接
    TIMEOUT = "TIMEOUT"
    DEFAULT_TIMEOUT = TRSConstants.DEFAULT_TIMEOUT

    # 连接超时设置 timeout 单位为毫秒,小于或等于0时采用系统缺省值;
    # ConnectParams 对象本身
    # 超时属性的设置对装库、数据导出操作无效
    def setTimeout(self, timeout):
        if timeout == 0 or timeout < 0:
            super().setProperty(ConnectParams.TIMEOUT, ConnectParams.DEFAULT_TIMEOUT)
        else:
            super().setProperty(ConnectParams.TIMEOUT, timeout)
        return self

    def getTimeout(self):
        value = super().getProperty(ConnectParams.TIMEOUT)
        if value is None:
            return ConnectParams.DEFAULT_TIMEOUT
        return value

    def setProperty(self, key, value):
        super.setProperty(key, value)
        return self
