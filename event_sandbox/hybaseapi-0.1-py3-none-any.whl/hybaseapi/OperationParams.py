from .TRSObject import TRSObject


class OperationParams(TRSObject):
    WAIT_FLUSH = "waitFlush"
    WAIT_SEARCHER = "waitSearcher"
    SOFT_COMMIT = "softCommit"

    def setWaitFlush(self, waitFlush):
        self.setProperty(self.WAIT_FLUSH, waitFlush)
        return self

    def isWaitFlush(self):
        value = self.getProperty(self.WAIT_FLUSH)
        return None

    def setWaitSearcher(self, waitSearcher):
        self.setProperty(self.WAIT_SEARCHER, waitSearcher)
        return self

    def isWaitSearcher(self):
        return self.getProperty(self.WAIT_SEARCHER)

    def setSoftCommit(self, softCommit):
        self.setProperty(self.SOFT_COMMIT, softCommit)
        return self

    def isSoftCommit(self):
        return self.getProperty(self.SOFT_COMMIT)



















