import platform
import re
import sys
import time
import uuid
import os
import io
from .RequestBuilder import RequestBuilder
from . import TRSConnection
from . import TRSFileBuilder
from .TRSRPC_pb2 import MaintRPC, ResultRecord, FileList, Property
from .TRSRecord import TRSRecord
from .SearchParams import SearchParams
import avro.schema
from avro.datafile import DataFileReader
from avro.io import DatumReader


class TRSExport:
    MAX_FILE_SIZE = 1 * 1024 * 1024 * 1024
    conn: TRSConnection = None
    timeout = 60 * 60
    exportBatch = 100000
    exportID = None
    attachDir = None
    attachDirAbsolute = None
    isStoreSourceFile = True
    exportVersion = 7
    recordListener = None

    def __init__(self, conn: TRSConnection = None, filePath=None, append=True, recordListener=None):
        self.options = {}
        if recordListener is not None:
            self.conn = conn
            self.recordListener = recordListener
        elif filePath is not None:
            self.conn = conn
            self.recordListener = TRSFileBuilder(filePath, True)

    def getProperty(self, name):
        return self.options.get(name)

    def setProperty(self, name, value):
        self.options.update({name: value})
        return self

    def setExportVersion(self, exportVersion):
        self.exportVersion = exportVersion

    def getIsStoreSourceFile(self):
        return self.isStoreSourceFile

    def setStoreSourceFile(self, val=True):
        self.isStoreSourceFile = val

    def setAttachmentDir(self, attacmentDir):
        _dir = self.modifyPath(attacmentDir)
        if _dir is None:
            return None
        fullPath = self.getFullAttachmentPath(_dir)
        systemPlatform = platform.system()
        if systemPlatform == "Linux" and fullPath[1] == ":":
            raise Exception("创建目录失败！请检查路径是否合法" + attacmentDir)
        if not os.path.exists(fullPath):
            try:
                os.makedirs(fullPath)
            except OSError:
                print("创建目录失败！请检查路径是否合法" + attacmentDir)

        self.attachDir = _dir
        self.attachDirAbsolute = fullPath

    @staticmethod
    def modifyPath(path):
        if path is None or path == "":
            return None
        path.replace("\\", "/", 1)
        path = path.rstrip("\\")
        return path

    def getFullAttachmentPath(self, _dir):
        if not self.isAbsolutePath(_dir):
            dataDir = self.getDataDir()
            _dir = dataDir + "/" + _dir
        return _dir

    @staticmethod
    def isAbsolutePath(path):
        if path[0] == '/' or (path[1] == ':' and path[2] == '/'):
            return True
        else:
            return False

    def getDataDir(self):
        s = self.recordListener.getDataDir()
        if s is None:
            return "/tmp"
        else:
            return s

    def getBatchSize(self):
        return self.exportBatch

    def resume(self, exportID, strSources, start, recordNum, subdbMap=None, params: SearchParams = None):
        if subdbMap is None:
            if strSources is None:
                raise Exception("strSources can't be null!")
            subdbMap = {}
            for db in re.split('[,;]', strSources):
                subdbMap.update({db: None})
        if params is None:
            params = SearchParams()
        if subdbMap is None:
            raise Exception("subdbMap can't be null!")
        if start < 0 or recordNum < 0:
            raise Exception("start or recordNum paramter can't be negative!")
        subdbList = ""
        for k, v in subdbMap.items():
            subdbs = v
            if subdbs is None or len(subdbs) == 0:
                if len(subdbList) > 0:
                    subdbList += ";"
                subdbList += k
                continue
            for sudb in subdbs:
                if len(subdbList) > 0:
                    subdbList += ";"
                subdbList += subdb + "@" + k

        if self.exportVersion > 7:
            return self.resume_8(exportID, str(subdbList), start, recordNum, params.getProperty("export.byuuid"))
        else:
            return self.resume_7(exportID, str(subdbList), start, recordNum)

    def resume_8(self, exportID, subdbList, start, recordNum, byUUID):
        if byUUID is None:
            byUUID = False
        exportedNum = 0
        count = 0
        self.recordListener.onBegin()
        batchStart = start
        batchSize = recordNum
        self.exportID = exportID
        count = 0
        while count < recordNum:
            if not byUUID:
                batchStart = start + count
                batchSize = min(self.getBatchSize(), recordNum - count)
            exportedNum = self.exportOneBatch(subdbList, exportID, batchStart, batchSize)
            if exportedNum < 0:
                break
            count += exportedNum
        if exportedNum >= 0:
            # 最后一次请求表示结束
            self.exportOneBatch(subdbList, exportID, sys.maxsize, 1)
        self.recordListener.onEnd()
        return count

    def exportOneBatch(self, strSources, exportID, start, num):
        if num == 0:
            return 0

        reqBuilder = MaintRPC.ExportRecordRequest()
        reqBuilder.source = strSources
        reqBuilder.exportID = exportID
        reqBuilder.start = start
        reqBuilder.num = num

        p1 = Property()
        p2 = Property()
        p1.key = "output.format.avro"
        p1.value = "1"
        p2.key = "STOREFILE"
        isStoreSourceFile = self.isStoreSourceFile
        p2.value = str(isStoreSourceFile).lower()
        reqBuilder.options.append(p1)
        reqBuilder.options.append(p2)
        request = reqBuilder
        requestBuf = request.SerializeToString()
        req = None
        respStream = None
        path = "/api/exportrecords.do"
        response = self.conn.sendHttpRequest(path, True, False, -1, data=requestBuf)
        try:
            protoLenHeader = response.headers["X-Hybase-ProtoLen"]
        except KeyError:
            protoLenHeader = None
        if protoLenHeader is not None:
            return self.saveRecordsWithFiles_proto(response.content, int(protoLenHeader))
        else:
            return self.saveRecordsWithFiles_avro(response.content, 0)

    def saveRecordsWithFiles_proto(self, _input, length):
        counter = 0
        if length == 0:
            if self.exportVersion > 7:
                return -1
        records = MaintRPC.ExportRecordResponse()
        inputLength = len(_input)
        recordsBytes = _input[0:length]
        records.ParseFromString(recordsBytes)
        exportID = records.exportID
        if exportID != self.exportID:
            raise Exception("export id error")
        appendixNum = records.appendixNum

        if appendixNum > 0:
            fileBytes = _input[length:]
            path = self.getAttachmentDir()
            if path is None:
                path = "attachment" + str(time.time())
                self.setAttachmentDir(path)
            i = 0
            while i < appendixNum:
                headBuffer = fileBytes[0:4]
                fileBytes = fileBytes[4:]
                headSize = int.from_bytes(headBuffer, byteorder='big', signed=False)
                headBytes = fileBytes[0:headSize]
                fileBytes = fileBytes[headSize:]
                header = MaintRPC.ExportFileHeader()
                header.ParseFromString(headBytes)
                filename = header.fileName
                if filename.find("/") >= 0:
                    lastIndex = str.rindex("/")
                    filePath = self.attachDirAbsolute + "/" + filename[0:lastIndex]
                    if not os.path.exists(filePath):
                        os.makedirs(filePath)
                file2Write = open(self.attachDirAbsolute + "/" + filename, "wb")
                while True:
                    if len(fileBytes) == 0:
                        break
                    fileBuffer = fileBytes[0:4]
                    fileBytes = fileBytes[4:]
                    batchSize = int.from_bytes(fileBuffer, byteorder='big', signed=False)
                    batchBytes = fileBytes[0:batchSize]
                    fileBytes = fileBytes[batchSize:]
                    file2Write.write(batchBytes)
                file2Write.close()
                i += 1

        counter += self.parseRecords(records)
        return counter

    def saveRecordsWithFiles_avro(self, _input, length):
        try:
            recNum = 0
            bio = io.BytesIO(_input)
            reader = DataFileReader(bio, DatumReader())
            schema = avro.schema.parse(reader.schema)
            for data in reader:
                record = TRSRecord()
                record.recTag = TRSRecord.EXPORT
                record.dbName = schema.name
                record.UUID = data["uuid"]
                record.timestamp = data["timestamp"]
                for k, v in data.items():
                    record.addValue(colName=k, val=v)
                self.recordListener.onRecord(record)
                recNum += 1
            reader.close()
            return recNum
        except BaseException as error:
            print('error while saveRecordsWithFiles_avro ' + str(_input))
            raise error

    def parseRecords(self, records: MaintRPC.ExportRecordResponse):
        recordList = records.record
        for r in recordList:
            processOk = self.recordListener.onRecord(self.convertToTRSRecord(r))
            if not processOk:
                print("AlreadyClosed")
                raise Exception("AlreadyClosed")
        return len(recordList)

    def convertToTRSRecord(self, resultRecord: ResultRecord):
        record = TRSRecord()
        record.setRecTag(TRSRecord.EXPORT)
        record.setDbName(resultRecord.dbName)
        record.setUid(resultRecord.uid)
        record.setTimestamp(resultRecord.timestamp)
        if len(resultRecord.columns) > 0:
            for c in resultRecord.columns:
                if c.files is not None and len(c.files.files) > 0:
                    flBuilder = FileList()
                    fl = c.files
                    for f in fl.files:
                        f.name = self.getAttachmentDir() + "/" + f.name
                        flBuilder.files.append(f)
                    c.files.CopyFrom(flBuilder)
                record.addValue(c.name, c)
        return record

    def getAttachmentDir(self):
        return self.attachDir

    def export(self, strSourceDBs, query, start, recordNum, params: SearchParams = None):
        if strSourceDBs is None:
            raise Exception('strSources can\'t be null!')
        subdbMap = {}
        for db in strSourceDBs.split('[,;]'):
            subdbMap.update({db: None})
        return self.export_with_map(subdbMap, query, start, recordNum, params)

    def export_with_map(self, subdbMap, query, start, recordNum, params: SearchParams = None):
        if subdbMap is None:
            raise Exception('subdbMap can\'t be null!')
        if params is None:
            raise Exception('params can\'t be null!')
        if start < 0 or recordNum < 0:
            raise Exception('start or recordNum paramter can\'t be negative!')
        subdbList = '';
        for key, value in subdbMap.items():
            subdbs = value
            if subdbs is None or len(subdbs) == 0:
                if len(subdbList) > 0:
                    subdbList += ';'
                subdbList += key
                continue

            for subdb in subdbs:
                if len(subdbList) > 0:
                    subdbList += ';'
                subdbList = subdbList + subdb + '@' + key

        sr = RequestBuilder.buildSearchReq(subdbList, query, start, recordNum, params)
        reqBuilder = MaintRPC.ExportRecordRequest()
        reqBuilder.source = subdbList
        reqBuilder.searchRequest.CopyFrom(sr)
        request = reqBuilder

        response = None
        try:
            path = "/api/exportrecords.do?action=getExportID"
            response = self.conn.sendHttpRequest(path, True, False, -1, data=request.SerializeToString())
            versionHeader = response.headers["Export-Version"]
            self.exportVersion = 7
            if versionHeader is not None:
                self.exportVersion = int(versionHeader)
            exportRecordResponse = MaintRPC.ExportRecordResponse()
            exportRecordResponse.ParseFromString(response.content)
            self.exportID = exportRecordResponse.exportID
        except BaseException as error:
            raise Exception(repr(error))
        finally:
            response.close()
        # def resume(self, exportID, strSources, start, recordNum, subdbMap=None, params: SearchParams = None):
        return self.resume(self.exportID, None, start, recordNum, subdbMap, params)
