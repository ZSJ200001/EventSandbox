from .TRSRecord import TRSRecord


class RecordListener:
    resultNoSortSet = None

    def __init__(self, resultNoSortSet=None):
        self.resultNoSortSet = resultNoSortSet

    @staticmethod
    def getDataDir():
        return None

    @staticmethod
    def onBegin():
        return None

    def onRecord(self, record: TRSRecord):
        while True:
            if self.resultNoSortSet.closed or self.resultNoSortSet.failure is not None:
                return False
            if self.resultNoSortSet.resultSize <= self.resultNoSortSet.MaxRecordsSize:
                length = record.computeSize(False)
                self.resultNoSortSet.records.put(record)
                self.resultNoSortSet.resultSize += length
                return True

    def onEnd(self):
        self.resultNoSortSet.closed = True

