from hybaseapi import TRSRPC_pb2
from hybaseapi import TRSConnection
from .TRSConstants import TRSConstants
from .TRSRPC_pb2 import SearchRPC
from .TRSRecord import TRSRecord
from .TRSResultNoSortSet import TRSResultNoSortSet
from .TRSResultSet import TRSResultSet


class ResultSetParser:
    @staticmethod
    def processSearchResponse(searchResponse: SearchRPC.SearchRecordResponse, conn: TRSConnection):
        resultSet = TRSResultSet(conn)
        if searchResponse.statusCode != 0:
            return None
        resultSet.searchid = searchResponse.searchid
        resultSet.numFound = searchResponse.numFound
        resultList = searchResponse.record
        if resultList is not None:
            for re in resultList:
                record = TRSRecord(conn)
                record.setUid(re.uid)
                record.setRelevance(re.relevance)
                record.setDbName(re.dbName)
                record.setTimestamp(re.timestamp)
                for col in re.columns:
                    record.addValue(col.name, col)
                resultSet.add(record)

        if len(searchResponse.searchProgress) > 0:
            mergeNum = 0
            totalNum = 1
            for progressInfo in searchResponse.getSearchProgressList():
                if progressInfo.getKey().lower() == TRSConstants.MERGENUM.lower():
                    mergeNum = int(progressInfo.getValue())
                    continue
                if progressInfo.getKey().lower() == TRSConstants.TOTALNUM.lower():
                    totalNum = int(progressInfo.getValue())
                    continue

                resultSet.dbHitsNum.update({progressInfo.getKey(): int(progressInfo.getValue())})
            resultSet.progress = str((mergeNum / totalNum) * 100) + "%"

        if len(searchResponse.dbHitsMap) > 0:
            for pty in searchResponse.dbHitsMap:
                dbName = pty.key
                hit = int(pty.value)
                try:
                    idx = dbName.index("#")
                except ValueError:
                    idx = -1
                if idx > 0:
                    view = dbName[0: idx]
                    num = resultSet.dbHitsNum.get(view)
                    if num is None:
                        resultSet.dbHitsNum.update({view: hit})
                    else:
                        resultSet.dbHitsNum.update({view: hit + num})
                resultSet.dbHitsNum.update({pty.key: hit})
        return resultSet

    @staticmethod
    def parserExportRecordResponse(result: TRSRPC_pb2.MaintRPC.ExportRecordResponse, conn: TRSConnection,
                                   exportVersion):
        exportID = result.exportID
        resultSet = TRSResultNoSortSet(conn)
        if len(result.status) == 0:
            raise Exception("export dbStatus is empty!")
        exportStatus = TRSRPC_pb2.MaintRPC.ExportStatus()
        exportStatus.ParseFromString(result.status.encode("ISO-8859-1"))
        resultSet.searchid = exportID
        numFound = 0
        for subInfo in exportStatus.subDB:
            hitsNum = subInfo.size
            dbName = subInfo.subID.split("@")[1]
            view = ""
            try:
                idx = dbName.index("#")
            except ValueError:
                idx = -1
            if idx > 0:
                view = dbName[0: idx]
            num = resultSet.dbHitsNum.get(dbName)
            if num is None:
                resultSet.dbHitsNum.update({dbName: hitsNum})
            else:
                resultSet.dbHitsNum.update({dbName: hitsNum + num})

            if len(view) > 0:
                num = resultSet.dbHitsNum.get(view)
                if num is None:
                    resultSet.dbHitsNum.update({view: hitsNum})
                else:
                    resultSet.dbHitsNum.update({view: hitsNum + num})
            numFound += hitsNum
            resultSet.setNumFound(numFound)
            resultSet.setSearchRequest(exportStatus.searchRequest)
            resultSet.setExportVersion(exportVersion)
        return resultSet

    @staticmethod
    def processCategoryResponse(categoryReponse: SearchRPC.CategoryQueryResponse):
        if categoryReponse.statusCode != 0:
            raise Exception("unexcpted status")
        categoryMap = {}
        for re in categoryReponse.result:
            if re.property is not None:
                re.property="0"
            if categoryMap.__contains__(re.property):
                categoryMap.get(re.property).update({re.key: re.value})
            else:
                resMap = {}
                resMap.update({re.key: re.value})
                categoryMap.update({re.property: resMap})
        totalHits = 0
        if categoryMap.__contains__("$total"):
            totalHits = categoryMap.pop("$total").get("$total")
        else:
            for key in list(categoryMap.keys()):
                if categoryMap.get(key).__contains__("$total"):
                    totalHits = categoryMap.get(key).pop("$total")
        if totalHits > 0:
            totalHits = totalHits - 1
        result = TRSResultSet(categoryMap=categoryMap,foundNum=totalHits)
        return result

    @classmethod
    def processExpressionResponse(cls, expressionReponse):
        result = None
        if expressionReponse.statusCode != 0:
            raise Exception("unexcpted status")
        expressionMap = {}
        for re in expressionReponse.result:
            expressionMap.update({re.name: re})
        numfound = expressionMap.get("$total")
        expressionMap.pop("$total",None)
        if numfound is None:
            numfoundArg = 0
        else:
            numfoundArg = numfound.numValue
        result = TRSResultSet(expressionMap=expressionMap, foundNum=numfoundArg)
        return result
