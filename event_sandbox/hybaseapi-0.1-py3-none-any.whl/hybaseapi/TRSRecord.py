import os
import base64
from tempfile import TemporaryFile
from dateutil.parser import parse
from hybaseapi import TRSRPC_pb2, SearchParams
from hybaseapi import TRSConnection
from hybaseapi import TRSConstants
from hybaseapi import TRSDatabase
from hybaseapi import TRSDatabaseColumn
from .TRSRPC_pb2 import ResultRecord, InputFile

ResultColumn = ResultRecord.ResultColumn


class TRSRecord:
    closed = False
    UUID = "#UUID"
    EXPORT = "#EXPORT"
    conn: TRSConnection = None
    searchParmas: SearchParams = None
    deleteFileOnClose = True
    recUUID = ""
    recTag = ""
    relevance = 1
    dbName = ""

    schema: TRSDatabase = None
    size = 0
    timestamp = None

    def __init__(self, connection: TRSConnection = None):
        self.recColumnsData = {}
        self.recColumnFiles = {}
        self.recColumnsData = {}
        self.conn = connection

    def addValue(self, colName=None, col=None, val=None):
        if col is not None:
            self.recColumnsData.update({colName: col})
        else:
            cBuilder = ResultColumn()
            cBuilder.name = colName
            cBuilder.value = val
            self.recColumnsData.update({colName: cBuilder()})

    @staticmethod
    def build(items):
        db = TRSDatabase()
        rec = TRSRecord()
        length = 2 * (len(items) / 2)
        i = 0
        while i < length:
            key = items[i]
            val = items[i + 1]
            newCol = TRSDatabaseColumn(key, TRSDatabaseColumn.TYPE_CHAR)
            db.addColumn(newCol)
            rec.addValue(key, val)
            i += 1
        db.freeze()
        rec.setSchema(db)
        return rec

    def setSearchParams(self, sp: SearchParams):
        self.searchParmas = sp
        self.deleteFileOnClose = (sp is None) or (not sp.getTmpKeepOnClose())

    def setSchema(self, schema: TRSDatabase):
        self.schema = schema

    def getSchema(self):
        return self.schema

    def reset(self):
        for files in self.recColumnFiles.values():
            for f in files:
                if os.path.isfile(f):
                    os.remove(f)
        self.recColumnFiles.clear()
        self.recColumnsData.clear()

    def close(self):
        if not self.closed:
            self.reset()

    def setUid(self, uid):
        self.recUUID = uid

    def getUid(self):
        return self.recUUID

    def getRelevance(self):
        return self.relevance

    def addValue(self, colName, val):
        self.recColumnsData.update({colName: val})

    def addValue(self, colName, val):
        cBuilder = ResultColumn()
        cBuilder.name = colName
        strVal = str(val)
        try:
            strVal = val.strValue
        except AttributeError:
            strVal = str(val)
        cBuilder.strValue = strVal
        self.recColumnsData.update({colName: cBuilder})

    def addValues(self, columns):
        self.recColumnsData.update(columns)

    def computeSize(self, reCompute):
        if self.size != 0 and not reCompute:
            return self.size
        length = 0
        for k,v in self.recColumnsData.items():
            length += len(k)
            length += len(v.strValue)
        self.size += length
        return self.size

    def getColumn(self, colName):
        return self.recColumnsData.get(colName)

    def getString(self, colName):
        if self.UUID.lower() == colName.lower():
            return self.getUid()
        col = self.getColumn(colName)
        if col is None:
            return None
        if col.strValue is not None:
            return col.strValue
        elif col.numValue is not None:
            return col.numValue
        elif col.floatValue is not None:
            return col.floatValue

        return None

    def getColumnNames(self):
        return self.recColumnsData.keySet()

    def getValue(self, colName):
        value = self.getString(colName)
        if value is None:
            return None
        token = value.split(TRSConstants.DEFALT_COLUMN_SEPCHAR)
        return token

    def getInt(self, colName):
        return self.getLong(colName)

    def getLong(self, colName):
        values = self.getValues(colName)
        if values is None or len(values) == 0:
            return 0
        try:
            return int(values[0])
        except (TypeError, ValueError):
            raise Exception("ERR_DATA_FORMAT")

    def getFloat(self, colName):
        values = self.getValues(colName)
        if values is None or len(values) == 0:
            return 0
        try:
            return float(values[0])
        except (TypeError, ValueError):
            raise Exception("ERR_DATA_FORMAT")

    def getDouble(self, colName):
        values = self.getValues(colName)
        if values is None or len(values) == 0:
            return 0
        try:
            return float(values[0])
        except (TypeError, ValueError):
            raise Exception("ERR_DATA_FORMAT")

    def getDate(self, colName):
        values = self.getValues(colName)
        if values is None or len(values) == 0:
            return None
        return parse(values)

    def getFileIds(self, colName):
        col = self.getColumn(colName)
        if col is None or (not col.hasFiles()) or col.getFiles().getFilesCount() == 0:
            return None
        fl = col.getFiles()
        idList = []

        for f in fl.getFilesList():
            if f.getIsDir():
                continue
            byteArray = InputFile.newBuilder(f).clearContent().clearFileLength().setUri(self.getUid()).build()
            byteArray = base64.b64encode(byteArray)
            idList.append(byteArray.decode())
        return idList

    def getFileFromDb(self, conn: TRSConnection, dbName, fid, fileDir):
        bs = base64.b64decode(fid)
        f = TRSRPC_pb2.InputFile.parseFrom(bs)
        return self.downloadFile(conn, f, f.getUri(), fileDir)

    def getFile(self, colName):
        col = self.getColumn(colName)
        if col is None or (not len(col.files.files)>0) or len(col.files.files) == 0:
            return None
        colFileList = self.recColumnFiles.get(colName)
        if colFileList is None:
            colFileList = []
            self.recColumnFiles.update({colName: colFileList})
        sb = ""
        fl: TRSRPC_pb2.FileList = col.getFiles()
        if getRecTag() == self.EXPORT:
            for f in fl.getFilesList():
                if len(sb) == 0:
                    sb += f.getName()
                else:
                    sb += ";" + f.getName()
            return sb
        elif len(colFileList) == 0:
            if self.searchParmas is None:
                fileDir = None
            else:
                fileDir = self.searchParmas.getTempLocalDir()
            for f in fl.getFilesList:
                tmpFile = self.downloadFile(self.conn, f, self.getUid(), fileDir)
                colFileList.append(tmpFile)
        sb = ""
        for f in colFileList:
            if len(sb) == 0:
                sb += os.path.abspath(f)
            else:
                sb += ";" + os.path.abspath(f)
        return sb

    @staticmethod
    def downloadFile(conn: TRSConnection, f: TRSRPC_pb2.InputFile, uuid, fileDir):
        fileID = f.getName()
        fileSuffix = f.getSuffix()
        lastEx = None
        tmpFile = None
        path = "/api/download.do?recordid=" + quote(uuid) + "&id=" + quote(fileID)
        r = requests.get(path)
        f = TemporaryFile('w+b')
        f.write(r.content)
        f.seek(0)
        return f

    def getValues(self, colName):
        value = self.getString(colName)
        if value is None:
            return None
        valStrings = value.split(TRSConstants.DEFALT_COLUMN_SEPCHAR)
        return valStrings

    def getColumnMap(self):
        return self.recColumnsData

    def setDbName(self, dbName):
        self.dbName = dbName

    def getDbName(self):
        return self.dbName

    def getRecTag(self):
        return self.recTag

    def setRecTag(self, tag):
        self.recTag = tag

    def getTimestamp(self):
        return self.timestamp

    def setTimestamp(self, timestamp):
        self.timestamp = timestamp

    def toString(self):
        return self.toTrsData("", None)

    def toString(self, _format):
        if _format == "trs":
            return self.toTrsData("", None)
        elif _format == "json":
            return self.toJsonData()

    def toJsonData(self):
        sb = "{"
        jsonNum = 0
        if self.schema is not None:
            jsonNum += 1
            sb += TRSUtils.renderJsonString("_db") + ":" + TRSUtils.renderJsonString(schema.getName())

    def toTrsData(self, prefix, reuse):
        if reuse is None:
            sb = ""
        else:
            sb = reuse
        sb += prefix + "<REC>\r\n"
        newline = "\r\n"
        for key in self.recColumnsData.keys():
            val = self.getString(key)
            if (val is not None) and len(val) != 0:
                if len(sb) > 0:
                    sb += newline
                sb += prefix + "<" + key + ">=" + val
        return sb

    def setRelevance(self, rel):
        self.relevance = rel
