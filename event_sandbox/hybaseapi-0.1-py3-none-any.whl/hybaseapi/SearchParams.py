from .TRSObject import TRSObject


class SearchParams(TRSObject):
    SORTMETHOD = "SORTMETHOD"
    DEFAULTCOL = "DEFAULTCOL"
    READCOLUMNS = "READCOLUMNS"
    COLORCOLUMNS = "COLORCOLUMNS"
    CUTSIZE = "CUTSIZE"
    EstimateUnit = "EstimateUnit"
    QuickSearch = "QuickSearch"
    TimeOut = "TimeOut"
    DEFAULT_SORTMETHOD = ""
    DEFAULT_DEFAULTCOLS = ""
    tmpfile_localDir = None
    tmpfile_keepOnClose = False

    def setSortMethod(self, sortMethod):
        self.setProperty(self.SORTMETHOD, sortMethod)

    def getSortMethod(self):
        value = self.getProperty(self.SORTMETHOD)
        if value is None:
            return self.DEFAULT_SORTMETHOD
        return value

    def setProperty(self, key, value):
        super().setProperty(key, value)

    def getProperty(self, key):
        value = self.properties.get(key)
        if value is None:
            value = self.properties.get(key.lower())
        return value

    def setDefaultColumn(self, defaultCol):
        self.setProperty(self.DEFAULTCOL, defaultCol)
        return self

    def setTimeOut(self, timeout):
        self.setProperty(self.TimeOut, str(timeout))
        return self

    def getTimeOut(self):
        value = self.getProperty(self.TimeOut)
        if value is None:
            return 60
        else:
            return Long(value)

    def getDefaultColumn(self):
        value = self.getProperty(self.DEFAULTCOL)
        if value is None:
            return self.DEFAULT_DEFAULTCOLS
        else:
            return value

    def setReadColumns(self, cols):
        self.setProperty(self.READCOLUMNS, cols)
        return self

    def getReadColumns(self):
        value = self.getProperty(self.READCOLUMNS)
        return value

    def setColorColumns(self, cols):
        self.setProperty(self.COLORCOLUMNS, cols)
        return self

    def getColorColumns(self):
        value = self.getProperty(self.COLORCOLUMNS)
        return value

    def setCutSize(self, size):
        self.setProperty(self.CUTSIZE, size)
        return self

    def getCutSize(self):
        value = self.getProperty(self.CUTSIZE)
        if value is None:
            return 0
        return value

    def setQuickSearch(self, isQuickSearch):
        self.setProperty(self.QuickSearch, isQuickSearch)
        return self

    def isQuickSearch(self):
        value = self.getProperty(self.QuickSearch)
        if value is None:
            return None
        return value

    def setTempDir(self, localDir, keepOnClose):
        self.tmpfile_localDir = localDir
        self.tmpfile_keepOnClose = keepOnClose

    def getTempLocalDir(self):
        return self.tmpfile_localDir

    def getTmpKeepOnClose(self):
        return self.tmpfile_keepOnClose

    def setEstimateUnit(self, unit):
        self.setProperty(self.EstimateUnit, unit)
        return self

    def getEstimateUnit(self):
        value = self.getProperty(self.EstimateUnit)
        if value is None:
            return 0
        return value

    def setFilterBuilder(self, newfilter):
        # todo 未确定python中BaseFilterBuilder的代替类
        return self

    def getExtendParams(self):
        ret = []
        for key in self.properties.keys():
            if key.find(".") >= 0:
                ret.append(key)
        return ret
