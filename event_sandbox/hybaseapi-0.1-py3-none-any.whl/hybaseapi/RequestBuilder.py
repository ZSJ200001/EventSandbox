import os

from .TRSConstants import TRSConstants
from .TRSInputColumn import TRSInputColumn
from .TRSInputRecord import TRSInputRecord
from .TRSRPC_pb2 import SearchRPC, FileList, MaintRPC, InputFile
from .TRSRPC_pb2 import Property
from .TRSRPC_pb2 import InputRecord
from .OperationParams import OperationParams
import re

from .SearchParams import SearchParams


class RequestBuilder:
    @staticmethod
    def buildAddReq(DBName, records, factory, param: OperationParams):
        if DBName is None:
            raise Exception("DBName can not be null!")
        if records is None or len(records) == 0:
            return None
        textExtractFilter = None
        if param is not None and param.properties.__contains__("server.doc.extract") and param.properties.get(
                "server.doc.extract") is True:
            textExtractFilter = {}
            extractFilter = param.properties.get("doc.extract.suffix.wl")
            if extractFilter is not None:
                wl = {}
                wl |= set((re.split('[,;]', extractFilter.lower())))
                textExtractFilter.update({"wl": wl})
            extractFilter = param.properties.get("doc.extract.suffix.bl")
            if extractFilter is not None:
                bl = {}
                bl |= (set(re.split('[,;]', extractFilter.lower())))
                textExtractFilter.update({"bl": bl})

        builder = TRSRPC.MaintRPC.InsertRecordRequest.InsertRecordRequest.newBuilder()
        builder.setSource(DBName)
        i = 0
        for r in records:
            record: InputRecord()
        # try:
        # record = buildRecord(r, factory, True, 0,param, textExtractFilter)

    @staticmethod
    def buildRecord(strSources, strWhere, start, num, params):
        return None

    @staticmethod
    def buildSearchReq(strSources, strWhere, start, num, params: SearchParams):
        searchBuilder = SearchRPC.SearchRecordRequest()
        searchBuilder.source = strSources
        searchBuilder.start = start
        searchBuilder.num = num
        if strWhere is not None:
            searchBuilder.query = strWhere
        searchBuilder.sortMethod = params.getSortMethod().replace("\\s+", "")

        if params.getReadColumns() is not None:
            searchBuilder.readColumns = params.getReadColumns()
        if params.getColorColumns() is not None:
            searchBuilder.colorColumns = params.getColorColumns()
        if params.isQuickSearch() is not None:
            searchBuilder.QuickSearch = params.isQuickSearch()

        searchBuilder.EstimateUnit = params.getEstimateUnit()
        searchBuilder.defaultColumn = params.getDefaultColumn()
        searchBuilder.cutSize = params.getCutSize()
        searchBuilder.timeout = params.getTimeOut()
        extOpt = params.getExtendParams()
        for key in extOpt:
            val = str(params.getProperty(key))
            if val is None or len(val) == 0:
                continue

            opt = Property()
            opt.key = key
            opt.value = val
            searchBuilder.opts.append(opt)

        request = searchBuilder
        return request

    @staticmethod
    def buildCategoryQueryReq(sources, query, defaultColumn, categoryColumn, topNum, params: SearchParams):
        cateQueryBuilder = SearchRPC.CategoryQueryRequest()
        cateQueryBuilder.source = sources
        if query is not None:
            cateQueryBuilder.query = query
        cateQueryBuilder.categoryColumn = categoryColumn
        if defaultColumn is not None:
            cateQueryBuilder.defaultColumn = defaultColumn
        if topNum > 256000:
            topNum = 256000
        cateQueryBuilder.num = topNum
        if params is not None:
            for k, v in params.properties.items():
                opt = Property()
                opt.key = k
                opt.value = v
                cateQueryBuilder.opts.append(opt)
        return cateQueryBuilder

    @staticmethod
    def buildFacetQueryReq(sources, query, defaultColumn, categoryColumns, topNum, params: SearchParams):
        facetQueryBuilder = SearchRPC.FacetQueryRequest.newBuilder()
        facetQueryBuilder.setSource(sources)
        if query is not None:
            facetQueryBuilder.setQuery(query)
        if defaultColumn is not None:
            facetQueryBuilder.setDefaultColumn(defaultColumn)
        if topNum > 256000:
            topNum = 256000
        facetQueryBuilder.setNum(topNum)
        for col in categoryColumns:
            colBuilder = TRSRPC.SearchRPC.FacetQueryRequest.InputFacetColumn.newBuilder()
            colBuilder.setName(col.getName())
            colBuilder.setStatColumn(col.getStatColumn())
            colBuilder.setFunction(col.getStatFunction())
            if col.hasFacetLabels():
                colBuilder.setFacetlabels(col.getFacetLabels())
            if col.hasMaxSize():
                colBuilder.setMaxResultsetSize(col.getMaxSize())
            options = col.getAllOptions()
            for key in options.keys():
                colBuilder.addOpts(Property.newBuilder().setKey(key).setValue(options.get(key)))
            facetQueryBuilder.addFacetColumn(colBuilder.build())
        if params is not None:
            for k, v in params.properties.items():
                opt = Property.newBuilder()
                opt.setKey(prop.getKey())
                opt.setValue(prop.getValue())
                facetQueryBuilder.addOpts(opt.build())
        return facetQueryBuilder.build()

    @staticmethod
    def buildExpressionQueryReq(sources, query, expression, params):
        builder = SearchRPC.ExpressionQueryRequest()
        builder.source = sources
        if query is not None:
            builder.query = query
        builder.expression = expression
        if params is not None:
            for k, v in params.properties.items():
                opt = Property()
                opt.key = k
                opt.value = v
                builder.opts.append(opt)
        return builder

    @staticmethod
    def buildInputRecord(inputRecord: TRSInputRecord, isNew, size, params: OperationParams):
        if inputRecord is None:
            return
        builder = InputRecord()
        builder.boost = inputRecord.getBoost()

        if not isNew:
            if inputRecord.getUid() is not None:
                builder.uid = inputRecord.getUid()
                size = len(inputRecord.getUid()) + size
            else:
                uniqueSearch = params.getProperty("unique.column.search")
                if uniqueSearch is None or not uniqueSearch:
                    raise Exception("更新记录没有指定uid")
        fieldNum = inputRecord.getColumnCount()
        fields = inputRecord.getColumns()
        skipFileError = False
        if params.getProperty("skip.file.error") is not None:
            skipFileError = params.getProperty("skip.file.error")
        skipErrorRec = False
        if params.getProperty("insert.skip.error") is not None:
            skipErrorRec = params.getProperty("insert.skip.error")

        i = 0
        while i < fieldNum:
            f: TRSInputColumn = list(fields)[i]
            valueString = f.getValue()
            fieldBuilder: InputRecord.InputColumn = InputRecord.InputColumn()
            fieldBuilder.boost = f.getBoost()
            fieldBuilder.name = f.getName()
            size = size + len(f.getName())

            if valueString is None or len(valueString) == 0:
                fieldBuilder.nullValue = True
            elif f.getColumnType() == TRSConstants.FILE_TYPE or f.getColumnType() == TRSConstants.DOCUMENT_TYPE:
                raise Exception("暂不支持导入文件")
                # fl = FileList()
                # paths = valueString.split(TRSConstants.DEFALT_COLUMN_SEPCHAR)
                # for path in paths:
                #     if os.path.exists(path) and os.path.isfile(path):
                #         continue
                #     inputFile = RequestBuilder.parseInputFile(path)
                #     fl.files.append(inputFile)

            else:
                fieldBuilder.strValue = valueString
                size = size + len(valueString)
            i = i + 1
            builder.columns.append(fieldBuilder)
        return [builder, size]

    @staticmethod
    def parseInputFile(file):
        inputFile = InputFile()
        inputFile.isDir = os.path.isdir(file)
        inputFile.fileLength = os.path.getsize(file)
        filename, extensionName = os.path.splitext(file)
        inputFile.name = filename
        inputFile.suffix = extensionName
        inputFile.uri = file
        return inputFile

    @staticmethod
    def buildDeleteReqByID(DBName: str, uids: [], options: {}):
        if DBName is None:
            raise Exception("DBName can not be null！")
        builder = MaintRPC.DeleteRecordRequest()
        builder.source = DBName
        if uids is not None:
            builder.id.extend(uids)
        if options is not None:
            for item in list(options.items()):
                builder.options.append(item)
        return builder

    @staticmethod
    def buildDeleteReqByQuery(DBName: str, query: [], param: SearchParams):
        builder = MaintRPC.DeleteRecordRequest()
        builder.source = DBName
        if query is not None:
            builder.query.extend(query)
        if param is not None:
            for item in list(param.properties.items()):
                builder.options.append(item)
        return builder
